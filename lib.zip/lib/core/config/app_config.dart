class AppConfig {
  AppConfig._();

  static const apiBaseUrl =
      'https://kwarihub-backend-production.up.railway.app/api/v1';

  static const storageBaseUrl =
      'https://kwarihub-backend-production.up.railway.app';

  static const appName = 'KwariHub';
  static const appTagline = 'Textile Marketplace';
}