import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:kwarihub/features/products/presentation/product_details_screen.dart';

import '../../features/auth/presentation/splash_screen.dart';
import '../../features/auth/presentation/onboarding_screen.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/register_screen.dart';
import '../../features/auth/presentation/verify_otp_screen.dart';

import '../../features/dashboard/presentation/dashboard_screen.dart';

import '../../features/categories/presentation/categories_screen.dart';

import '../../features/products/presentation/products_screen.dart';
import '../../features/products/presentation/products_screen.dart';

import '../../features/cart/presentation/cart_screen.dart';
import '../../features/checkout/presentation/checkout_screen.dart';
import '../../features/orders/presentation/orders_screen.dart';
import '../../features/wishlist/presentation/wishlist_screen.dart';
import '../../features/profile/presentation/profile_screen.dart';
import '../../features/wallet/presentation/wallet_screen.dart';
import '../../features/notifications/presentation/notifications_screen.dart';

import '../../features/vendor/presentation/vendor_dashboard_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/',

  routes: [
    // ============================================================
    // AUTH
    // ============================================================

    GoRoute(
      path: '/',
      builder: (context, state) {
        return const SplashScreen();
      },
    ),

    GoRoute(
      path: '/onboarding',
      builder: (context, state) {
        return const OnboardingScreen();
      },
    ),

    GoRoute(
      path: '/login',
      builder: (context, state) {
        return const LoginScreen();
      },
    ),

    GoRoute(
      path: '/register',
      builder: (context, state) {
        return const RegisterScreen();
      },
    ),

    GoRoute(
      path: '/verify-otp',
      builder: (context, state) {
        return const VerifyOtpScreen();
      },
    ),

    // ============================================================
    // CUSTOMER
    // ============================================================

    GoRoute(
      path: '/home',
      builder: (context, state) {
        return const DashboardScreen();
      },
    ),

    // ============================================================
    // CATEGORIES
    // ============================================================

    GoRoute(
      path: '/categories',
      builder: (context, state) {
        return const CategoriesScreen();
      },
    ),

    GoRoute(
      path: '/categories/:id',
      builder: (context, state) {
        final categoryId =
            state.pathParameters['id']!;

        return ProductsScreen(
          categoryId: categoryId,
        );
      },
    ),

    // ============================================================
    // PRODUCTS
    // ============================================================

    GoRoute(
      path: '/products',
      builder: (context, state) {
        return const ProductsScreen();
      },
    ),

    GoRoute(
      path: '/products/:id',
      builder: (context, state) {
        final productId =
            state.pathParameters['id']!;

        return ProductDetailsScreen(
          productId: productId,
        );
      },
    ),

    // ============================================================
    // CART
    // ============================================================

    GoRoute(
      path: '/cart',
      builder: (context, state) {
        return const CartScreen();
      },
    ),

    // ============================================================
    // CHECKOUT
    // ============================================================

    GoRoute(
      path: '/checkout',
      builder: (context, state) {
        return const CheckoutScreen();
      },
    ),

    // ============================================================
    // ORDERS
    // ============================================================

    GoRoute(
      path: '/orders',
      builder: (context, state) {
        return const OrdersScreen();
      },
    ),

    // ============================================================
    // WISHLIST
    // ============================================================

    GoRoute(
      path: '/wishlist',
      builder: (context, state) {
        return const WishlistScreen();
      },
    ),

    // ============================================================
    // PROFILE
    // ============================================================

    GoRoute(
      path: '/profile',
      builder: (context, state) {
        return const ProfileScreen();
      },
    ),

    // ============================================================
    // WALLET
    // ============================================================

    GoRoute(
      path: '/wallet',
      builder: (context, state) {
        return const WalletScreen();
      },
    ),

    // ============================================================
    // NOTIFICATIONS
    // ============================================================

    GoRoute(
      path: '/notifications',
      builder: (context, state) {
        return const NotificationsScreen();
      },
    ),

    // ============================================================
    // VENDOR
    // ============================================================

    GoRoute(
      path: '/vendor',
      builder: (context, state) {
        return const VendorDashboardScreen();
      },
    ),
  ],

  errorBuilder: (context, state) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline_rounded,
                size: 56,
                color: Color(0xFF0D5CC7),
              ),

              const SizedBox(height: 16),

              const Text(
                'Page Not Found',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFF102F4F),
                ),
              ),

              const SizedBox(height: 8),

              Text(
                state.uri.toString(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),

              const SizedBox(height: 20),

              ElevatedButton(
                onPressed: () {
                  context.go('/home');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      const Color(0xFF0D5CC7),
                  foregroundColor: Colors.white,
                  elevation: 0,
                ),
                child: const Text('Home'),
              ),
            ],
          ),
        ),
      ),
    );
  },
);