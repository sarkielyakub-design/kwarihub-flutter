class CartItemModel {
  final int id;
  final String uuid;
  final int userId;
  final int variantId;
  final int quantity;
  final String productName;
  final String? productImage;
  final String? color;
  final String? size;
  final String? material;
  final String variantSku;
  final double unitPrice;

  const CartItemModel({
    required this.id,
    required this.uuid,
    required this.userId,
    required this.variantId,
    required this.quantity,
    required this.productName,
    this.productImage,
    this.color,
    this.size,
    this.material,
    required this.variantSku,
    required this.unitPrice,
  });

  factory CartItemModel.fromJson(Map<String, dynamic> json) {
    return CartItemModel(
      id: _toInt(json['id']),
      uuid: json['uuid']?.toString() ?? '',
      userId: _toInt(json['user_id']),
      variantId: _toInt(json['variant_id']),
      quantity: _toInt(json['quantity']),
      productName: json['product_name']?.toString() ?? 'Unknown Product',
      productImage: json['product_image']?.toString(),
      color: json['color']?.toString(),
      size: json['size']?.toString(),
      material: json['material']?.toString(),
      variantSku: json['variant_sku']?.toString() ?? '',
      unitPrice: _toDouble(json['unit_price']),
    );
  }

  String? get name => productName;

  double? get price => unitPrice;

  double get itemTotal => unitPrice * quantity;

  static int _toInt(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value.toString()) ?? 0;
  }

  static double _toDouble(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value.toString()) ?? 0;
  }
}

class CartSummaryModel {
  final List<CartItemModel> items;
  final double subtotal;
  final int totalItems;

  const CartSummaryModel({
    required this.items,
    required this.subtotal,
    required this.totalItems,
  });

  factory CartSummaryModel.fromJson(Map<String, dynamic> json) {
    final rawItems = json['items'];

    return CartSummaryModel(
      items: rawItems is List
          ? rawItems
                .whereType<Map<String, dynamic>>()
                .map(CartItemModel.fromJson)
                .toList()
          : const [],
      subtotal: _toDouble(json['subtotal']),
      totalItems: _toInt(json['total_items']),
    );
  }

  static int _toInt(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value.toString()) ?? 0;
  }

  static double _toDouble(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value.toString()) ?? 0;
  }
}
