import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models/cart_model.dart';
import '../providers/cart_provider.dart';

class CartScreen extends ConsumerStatefulWidget {
  const CartScreen({super.key});

  @override
  ConsumerState<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends ConsumerState<CartScreen> {
  // ================================================================
  // COLORS
  // ================================================================

  static const Color primaryBlue = Color(0xFF0D5CC7);
  static const Color darkBlue = Color(0xFF102F4F);
  static const Color lightBlue = Color(0xFFF4F8FF);

  // ================================================================
  // REFRESH
  // ================================================================

  Future<void> _refresh() async {
    ref.invalidate(cartProvider);

    await ref.read(cartProvider.future);
  }

  // ================================================================
  // UPDATE QUANTITY
  // ================================================================

  Future<void> _updateQuantity(
    CartItemModel item,
    int quantity,
  ) async {
    if (quantity < 1) {
      return;
    }

    try {
      final api = ref.read(cartApiProvider);

      await api.updateCart(
        cartUuid: item.uuid,
        quantity: quantity,
      );

      ref.invalidate(cartProvider);
    } catch (e) {
      if (!mounted) return;

      _showMessage(
        _cleanError(e),
      );
    }
  }

  // ================================================================
  // REMOVE ITEM
  // ================================================================

  Future<void> _removeItem(
    CartItemModel item,
  ) async {
    try {
      final api = ref.read(cartApiProvider);

      await api.removeItem(
        item.uuid,
      );

      ref.invalidate(cartProvider);

      if (!mounted) return;

      _showMessage(
        'Item removed from cart.',
      );
    } catch (e) {
      if (!mounted) return;

      _showMessage(
        _cleanError(e),
      );
    }
  }

  // ================================================================
  // CLEAR CART
  // ================================================================

  Future<void> _clearCart() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Clear Cart',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: darkBlue,
            ),
          ),
          content: const Text(
            'Are you sure you want to remove all items from your cart?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(
                  false,
                );
              },
              child: const Text(
                'Cancel',
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(
                  true,
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryBlue,
                foregroundColor: Colors.white,
              ),
              child: const Text(
                'Clear',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    try {
      final api = ref.read(cartApiProvider);

      await api.clearCart();

      ref.invalidate(cartProvider);

      if (!mounted) return;

      _showMessage(
        'Cart cleared successfully.',
      );
    } catch (e) {
      if (!mounted) return;

      _showMessage(
        _cleanError(e),
      );
    }
  }

  // ================================================================
  // ERROR CLEANER
  // ================================================================

  String _cleanError(
    Object error,
  ) {
    return error
        .toString()
        .replaceFirst(
          'Exception: ',
          '',
        );
  }

  // ================================================================
  // MESSAGE
  // ================================================================

  void _showMessage(
    String message,
  ) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            message,
          ),
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(
            16,
            0,
            16,
            82,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
              12,
            ),
          ),
        ),
      );
  }

  // ================================================================
  // NAVIGATION
  // ================================================================

  void _goToHome() {
    context.go('/');
  }

  void _goToCategories() {
    context.go('/categories');
  }

  void _goToCart() {
    context.go('/cart');
  }

  void _goToWishlist() {
    context.go('/wishlist');
  }

  void _goToProfile() {
    context.go('/profile');
  }

  // ================================================================
  // CART BACK
  // ================================================================

  /// Return to the previous page when navigation history exists.
  ///
  /// If there is no previous route, return to the authenticated
  /// dashboard instead of leaving the customer area.
  void _goBack() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go('/dashboard');
    }
  }

  // ================================================================
  // BUILD
  // ================================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    final cartAsync = ref.watch(
      cartProvider,
    );

    return Scaffold(
      backgroundColor: Colors.white,

      // ============================================================
      // APP BAR
      // ============================================================

      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: darkBlue,
        elevation: 0,
        surfaceTintColor: Colors.white,

        automaticallyImplyLeading: false,

        // ----------------------------------------------------------
        // BACK BUTTON
        // ----------------------------------------------------------

        leading: IconButton(
          onPressed: _goBack,
          tooltip: 'Back',
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 21,
            color: darkBlue,
          ),
        ),

        titleSpacing: 0,

        // ----------------------------------------------------------
        // TITLE
        // ----------------------------------------------------------

        title: const Text(
          'My Cart',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: darkBlue,
          ),
        ),

        // ----------------------------------------------------------
        // CLEAR CART
        // ----------------------------------------------------------

        actions: [
          cartAsync.when(
            data: (cart) {
              if (cart.items.isEmpty) {
                return const SizedBox.shrink();
              }

              return IconButton(
                onPressed: _clearCart,
                tooltip: 'Clear cart',
                icon: const Icon(
                  Icons.delete_outline_rounded,
                  color: darkBlue,
                  size: 23,
                ),
              );
            },
            loading: () {
              return const SizedBox.shrink();
            },
            error: (_, __) {
              return const SizedBox.shrink();
            },
          ),

          const SizedBox(
            width: 8,
          ),
        ],
      ),

      // ============================================================
      // BODY
      // ============================================================

      body: SafeArea(
        bottom: false,

        child: cartAsync.when(
          // ========================================================
          // LOADING
          // ========================================================

          loading: () {
            return const _CartLoading();
          },

          // ========================================================
          // ERROR
          // ========================================================

          error: (
            error,
            stackTrace,
          ) {
            return _CartError(
              message: _cleanError(
                error,
              ),
              onRetry: _refresh,
            );
          },

          // ========================================================
          // DATA
          // ========================================================

          data: (
            cart,
          ) {
            // ------------------------------------------------------
            // EMPTY CART
            // ------------------------------------------------------

            if (cart.items.isEmpty) {
              return RefreshIndicator(
                color: primaryBlue,
                onRefresh: _refresh,

                child: ListView(
                  physics:
                      const AlwaysScrollableScrollPhysics(
                    parent:
                        BouncingScrollPhysics(),
                  ),

                  padding:
                      const EdgeInsets.only(
                    bottom: 120,
                  ),

                  children: const [
                    SizedBox(
                      height: 120,
                    ),
                    _EmptyCart(),
                  ],
                ),
              );
            }

            // ------------------------------------------------------
            // CART WITH ITEMS
            // ------------------------------------------------------

            return RefreshIndicator(
              color: primaryBlue,
              onRefresh: _refresh,

              child: CustomScrollView(
                physics:
                    const AlwaysScrollableScrollPhysics(
                  parent:
                      BouncingScrollPhysics(),
                ),

                slivers: [
                  // =================================================
                  // ITEM COUNT
                  // =================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        20,
                        10,
                        20,
                        4,
                      ),

                      child: Row(
                        children: [
                          Container(
                            padding:
                                const EdgeInsets.symmetric(
                              horizontal: 13,
                              vertical: 7,
                            ),

                            decoration:
                                BoxDecoration(
                              color: lightBlue,
                              borderRadius:
                                  BorderRadius.circular(
                                20,
                              ),
                            ),

                            child: Text(
                              '${cart.totalItems} '
                              '${cart.totalItems == 1 ? 'item' : 'items'}',

                              style:
                                  const TextStyle(
                                fontSize: 12,
                                fontWeight:
                                    FontWeight.w800,
                                color:
                                    primaryBlue,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // =================================================
                  // CART ITEMS
                  // =================================================

                  SliverPadding(
                    padding:
                        const EdgeInsets.fromLTRB(
                      20,
                      12,
                      20,
                      0,
                    ),

                    sliver:
                        SliverList.separated(
                      itemCount:
                          cart.items.length,

                      separatorBuilder:
                          (
                        _,
                        __,
                      ) {
                        return const SizedBox(
                          height: 12,
                        );
                      },

                      itemBuilder:
                          (
                        context,
                        index,
                      ) {
                        final item =
                            cart.items[index];

                        return _CartItemCard(
                          item: item,

                          onMinus: () {
                            _updateQuantity(
                              item,
                              item.quantity - 1,
                            );
                          },

                          onPlus: () {
                            _updateQuantity(
                              item,
                              item.quantity + 1,
                            );
                          },

                          onRemove: () {
                            _removeItem(
                              item,
                            );
                          },
                        );
                      },
                    ),
                  ),

                  // =================================================
                  // SUMMARY
                  // =================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        20,
                        26,
                        20,
                        10,
                      ),

                      child: _CartSummary(
                        cart: cart,
                      ),
                    ),
                  ),

                  // =================================================
                  // CHECKOUT
                  // =================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        20,
                        12,
                        20,
                        30,
                      ),

                      child: SizedBox(
                        width:
                            double.infinity,

                        height: 55,

                        child:
                            ElevatedButton(
                          onPressed: () {
                            context.push(
                              '/checkout',
                            );
                          },

                          style:
                              ElevatedButton
                                  .styleFrom(
                            backgroundColor:
                                primaryBlue,

                            foregroundColor:
                                Colors.white,

                            elevation: 0,

                            shape:
                                RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius
                                      .circular(
                                15,
                              ),
                            ),
                          ),

                          child: Row(
                            mainAxisAlignment:
                                MainAxisAlignment
                                    .center,

                            children: const [
                              Icon(
                                Icons
                                    .shopping_bag_outlined,
                                size: 20,
                              ),

                              SizedBox(
                                width: 9,
                              ),

                              Text(
                                'Proceed to Checkout',

                                style:
                                    TextStyle(
                                  color:
                                      Colors.white,
                                  fontSize:
                                      15,
                                  fontWeight:
                                      FontWeight
                                          .w800,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  // =================================================
                  // BOTTOM SPACE
                  // =================================================

                  const SliverToBoxAdapter(
                    child: SizedBox(
                      height: 20,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),

      // ============================================================
      // BOTTOM NAVIGATION
      // ============================================================

      bottomNavigationBar:
          _CartBottomNavigation(
        currentIndex: 2,

        onHome: _goToHome,

        onCategories:
            _goToCategories,

        onCart: _goToCart,

        onWishlist:
            _goToWishlist,

        onProfile:
            _goToProfile,
      ),
    );
  }
}

// ====================================================================
// CART ITEM CARD
// ====================================================================

class _CartItemCard extends StatelessWidget {
  const _CartItemCard({
    required this.item,
    required this.onMinus,
    required this.onPlus,
    required this.onRemove,
  });

  final CartItemModel item;

  final VoidCallback onMinus;
  final VoidCallback onPlus;
  final VoidCallback onRemove;

  static const Color primaryBlue =
      Color(0xFF0D5CC7);

  static const Color darkBlue =
      Color(0xFF102F4F);

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.all(
        12,
      ),

      decoration:
          BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(
          18,
        ),

        border: Border.all(
          color:
              const Color(
            0xFFE3EAF3,
          ),
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withValues(
              alpha: 0.035,
            ),

            blurRadius: 12,

            offset:
                const Offset(
              0,
              4,
            ),
          ),
        ],
      ),

      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          // ========================================================
          // PRODUCT IMAGE
          // ========================================================

          _ProductImage(
            imageUrl:
                item.productImage,
          ),

          const SizedBox(
            width: 13,
          ),

          // ========================================================
          // PRODUCT INFORMATION
          // ========================================================

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                // --------------------------------------------------
                // PRODUCT NAME + REMOVE
                // --------------------------------------------------

                Row(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,

                  children: [
                    Expanded(
                      child: Text(
                        item.productName,

                        maxLines: 2,

                        overflow:
                            TextOverflow
                                .ellipsis,

                        style:
                            const TextStyle(
                          fontSize: 15,
                          height: 1.2,
                          fontWeight:
                              FontWeight
                                  .w800,
                          color:
                              darkBlue,
                        ),
                      ),
                    ),

                    const SizedBox(
                      width: 4,
                    ),

                    InkWell(
                      onTap: onRemove,

                      borderRadius:
                          BorderRadius
                              .circular(
                        20,
                      ),

                      child:
                          const Padding(
                        padding:
                            EdgeInsets.all(
                          3,
                        ),

                        child: Icon(
                          Icons
                              .close_rounded,
                          size: 19,
                          color:
                              Colors.grey,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(
                  height: 6,
                ),

                // --------------------------------------------------
                // VARIANT
                // --------------------------------------------------

                _VariantInfo(
                  item: item,
                ),

                const SizedBox(
                  height: 9,
                ),

                // --------------------------------------------------
                // UNIT PRICE
                // --------------------------------------------------

                Text(
                  _money(
                    item.unitPrice,
                  ),

                  style:
                      const TextStyle(
                    fontSize: 16,
                    fontWeight:
                        FontWeight
                            .w900,
                    color:
                        primaryBlue,
                  ),
                ),

                const SizedBox(
                  height: 9,
                ),

                // --------------------------------------------------
                // QUANTITY + ITEM TOTAL
                // --------------------------------------------------

                Row(
                  children: [
                    _QuantityController(
                      quantity:
                          item.quantity,

                      onMinus:
                          onMinus,

                      onPlus:
                          onPlus,
                    ),

                    const Spacer(),

                    Flexible(
                      child: Text(
                        _money(
                          item.itemTotal,
                        ),

                        maxLines: 1,

                        overflow:
                            TextOverflow
                                .ellipsis,

                        textAlign:
                            TextAlign.end,

                        style:
                            const TextStyle(
                          fontSize: 15,
                          fontWeight:
                              FontWeight
                                  .w900,
                          color:
                              darkBlue,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _money(
    dynamic value,
  ) {
    final number =
        value is num
            ? value.toDouble()
            : double.tryParse(
                  value.toString(),
                ) ??
                0;

    return '₦${number.toStringAsFixed(2)}';
  }
}

// ====================================================================
// PRODUCT IMAGE
// ====================================================================

class _ProductImage
    extends StatelessWidget {
  const _ProductImage({
    required this.imageUrl,
  });

  final String? imageUrl;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      width: 88,
      height: 105,

      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFF4F8FF,
        ),

        borderRadius:
            BorderRadius.circular(
          14,
        ),
      ),

      clipBehavior:
          Clip.antiAlias,

      child:
          imageUrl != null &&
                  imageUrl!
                      .trim()
                      .isNotEmpty
              ? Image.network(
                  imageUrl!,
                  fit: BoxFit.cover,

                  errorBuilder:
                      (
                    context,
                    error,
                    stackTrace,
                  ) {
                    return const Icon(
                      Icons
                          .image_not_supported_outlined,
                      size: 34,
                      color:
                          Color(
                        0xFF0D5CC7,
                      ),
                    );
                  },

                  loadingBuilder:
                      (
                    context,
                    child,
                    loadingProgress,
                  ) {
                    if (loadingProgress ==
                        null) {
                      return child;
                    }

                    return const Center(
                      child:
                          SizedBox(
                        width: 22,
                        height: 22,
                        child:
                            CircularProgressIndicator(
                          strokeWidth: 2,
                          color:
                              Color(
                            0xFF0D5CC7,
                          ),
                        ),
                      ),
                    );
                  },
                )
              : const Icon(
                  Icons.image_outlined,
                  size: 38,
                  color:
                      Color(
                    0xFF0D5CC7,
                  ),
                ),
    );
  }
}

// ====================================================================
// VARIANT INFORMATION
// ====================================================================

class _VariantInfo
    extends StatelessWidget {
  const _VariantInfo({
    required this.item,
  });

  final CartItemModel item;

  @override
  Widget build(
    BuildContext context,
  ) {
    final values =
        <String>[];

    if (item.color != null &&
        item.color!
            .trim()
            .isNotEmpty) {
      values.add(
        'Color: ${item.color}',
      );
    }

    if (item.size != null &&
        item.size!
            .trim()
            .isNotEmpty) {
      values.add(
        'Size: ${item.size}',
      );
    }

    if (item.material != null &&
        item.material!
            .trim()
            .isNotEmpty) {
      values.add(
        'Material: ${item.material}',
      );
    }

    if (values.isEmpty) {
      return Text(
        'SKU: ${item.variantSku}',

        maxLines: 1,

        overflow:
            TextOverflow.ellipsis,

        style: TextStyle(
          fontSize: 12,
          color:
              Colors.grey.shade600,
          fontWeight:
              FontWeight.w500,
        ),
      );
    }

    return Text(
      values.join(' • '),

      maxLines: 2,

      overflow:
          TextOverflow.ellipsis,

      style: TextStyle(
        fontSize: 12,
        height: 1.3,
        color:
            Colors.grey.shade600,
        fontWeight:
            FontWeight.w500,
      ),
    );
  }
}

// ====================================================================
// QUANTITY CONTROLLER
// ====================================================================

class _QuantityController
    extends StatelessWidget {
  const _QuantityController({
    required this.quantity,
    required this.onMinus,
    required this.onPlus,
  });

  final int quantity;

  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      height: 38,

      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFF8FAFD,
        ),

        borderRadius:
            BorderRadius.circular(
          11,
        ),

        border: Border.all(
          color:
              const Color(
            0xFFE1E8F1,
          ),
        ),
      ),

      child: Row(
        mainAxisSize:
            MainAxisSize.min,

        children: [
          IconButton(
            onPressed:
                quantity > 1
                    ? onMinus
                    : null,

            padding:
                EdgeInsets.zero,

            constraints:
                const BoxConstraints(
              minWidth: 36,
              minHeight: 38,
            ),

            icon:
                const Icon(
              Icons
                  .remove_rounded,
              size: 17,
            ),
          ),

          Text(
            '$quantity',

            style:
                const TextStyle(
              fontSize: 13,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(
                0xFF102F4F,
              ),
            ),
          ),

          IconButton(
            onPressed:
                onPlus,

            padding:
                EdgeInsets.zero,

            constraints:
                const BoxConstraints(
              minWidth: 36,
              minHeight: 38,
            ),

            icon:
                const Icon(
              Icons
                  .add_rounded,
              size: 17,
            ),
          ),
        ],
      ),
    );
  }
}

// ====================================================================
// CART SUMMARY
// ====================================================================

class _CartSummary
    extends StatelessWidget {
  const _CartSummary({
    required this.cart,
  });

  final CartSummaryModel cart;

  static const Color primaryBlue =
      Color(0xFF0D5CC7);

  static const Color darkBlue =
      Color(0xFF102F4F);

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.all(
        18,
      ),

      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFFAFCFF,
        ),

        borderRadius:
            BorderRadius.circular(
          18,
        ),

        border: Border.all(
          color:
              const Color(
            0xFFE2EAF3,
          ),
        ),
      ),

      child: Column(
        children: [
          // ========================================================
          // SUBTOTAL
          // ========================================================

          Row(
            children: [
              const Expanded(
                child: Text(
                  'Subtotal',
                  style:
                      TextStyle(
                    fontSize: 14,
                    color:
                        Colors.grey,
                  ),
                ),
              ),

              Text(
                _money(
                  cart.subtotal,
                ),

                style:
                    const TextStyle(
                  fontSize: 17,
                  fontWeight:
                      FontWeight.w900,
                  color:
                      darkBlue,
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 12,
          ),

          const Divider(
            height: 1,
          ),

          const SizedBox(
            height: 12,
          ),

          // ========================================================
          // TOTAL ITEMS
          // ========================================================

          Row(
            children: [
              const Expanded(
                child: Text(
                  'Total items',
                  style:
                      TextStyle(
                    fontSize: 14,
                    color:
                        Colors.grey,
                  ),
                ),
              ),

              Text(
                '${cart.totalItems}',

                style:
                    const TextStyle(
                  fontSize: 14,
                  fontWeight:
                      FontWeight.w800,
                  color:
                      darkBlue,
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 15,
          ),

          // ========================================================
          // TOTAL
          // ========================================================

          Row(
            children: [
              const Expanded(
                child: Text(
                  'Total',

                  style:
                      TextStyle(
                    fontSize: 17,
                    fontWeight:
                        FontWeight.w900,
                    color:
                        darkBlue,
                  ),
                ),
              ),

              Text(
                _money(
                  cart.subtotal,
                ),

                style:
                    const TextStyle(
                  fontSize: 20,
                  fontWeight:
                      FontWeight.w900,
                  color:
                      primaryBlue,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _money(
    dynamic value,
  ) {
    final number =
        value is num
            ? value.toDouble()
            : double.tryParse(
                  value.toString(),
                ) ??
                0;

    return '₦${number.toStringAsFixed(2)}';
  }
}

// ====================================================================
// EMPTY CART
// ====================================================================

class _EmptyCart
    extends StatelessWidget {
  const _EmptyCart();

  static const Color primaryBlue =
      Color(0xFF0D5CC7);

  static const Color darkBlue =
      Color(0xFF102F4F);

  @override
  Widget build(
    BuildContext context,
  ) {
    return Center(
      child: Padding(
        padding:
            const EdgeInsets.symmetric(
          horizontal: 24,
        ),

        child: Column(
          children: [
            Container(
              width: 105,
              height: 105,

              decoration:
                  BoxDecoration(
                color:
                    const Color(
                  0xFFF4F8FF,
                ),

                borderRadius:
                    BorderRadius
                        .circular(
                  30,
                ),
              ),

              child: const Icon(
                Icons
                    .shopping_cart_outlined,
                size: 48,
                color:
                    primaryBlue,
              ),
            ),

            const SizedBox(
              height: 22,
            ),

            const Text(
              'Your Cart is Empty',

              textAlign:
                  TextAlign.center,

              style:
                  TextStyle(
                fontSize: 21,
                fontWeight:
                    FontWeight.w900,
                color:
                    darkBlue,
              ),
            ),

            const SizedBox(
              height: 8,
            ),

            Text(
              'Products you add to your cart will appear here.',

              textAlign:
                  TextAlign.center,

              style: TextStyle(
                fontSize: 14,
                height: 1.5,
                color:
                    Colors.grey
                        .shade600,
              ),
            ),

            const SizedBox(
              height: 25,
            ),

            SizedBox(
              height: 48,

              child:
                  ElevatedButton(
                onPressed: () {
                  context.go(
                    '/categories',
                  );
                },

                style:
                    ElevatedButton
                        .styleFrom(
                  backgroundColor:
                      primaryBlue,

                  foregroundColor:
                      Colors.white,

                  elevation: 0,

                  padding:
                      const EdgeInsets
                          .symmetric(
                    horizontal: 25,
                  ),

                  shape:
                      RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius
                            .circular(
                      13,
                    ),
                  ),
                ),

                child:
                    const Text(
                  'Continue Shopping',

                  style:
                      TextStyle(
                    color:
                        Colors.white,
                    fontWeight:
                        FontWeight
                            .w800,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ====================================================================
// LOADING
// ====================================================================

class _CartLoading
    extends StatelessWidget {
  const _CartLoading();

  @override
  Widget build(
    BuildContext context,
  ) {
    return const Center(
      child:
          CircularProgressIndicator(
        color:
            Color(
          0xFF0D5CC7,
        ),
      ),
    );
  }
}

// ====================================================================
// ERROR
// ====================================================================

class _CartError
    extends StatelessWidget {
  const _CartError({
    required this.message,
    required this.onRetry,
  });

  final String message;

  final Future<void>
      Function()
      onRetry;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Center(
      child: Padding(
        padding:
            const EdgeInsets.all(
          24,
        ),

        child: Column(
          mainAxisAlignment:
              MainAxisAlignment
                  .center,

          children: [
            Container(
              width: 75,
              height: 75,

              decoration:
                  BoxDecoration(
                color:
                    const Color(
                  0xFFF4F8FF,
                ),

                borderRadius:
                    BorderRadius
                        .circular(
                  22,
                ),
              ),

              child: const Icon(
                Icons
                    .cloud_off_rounded,
                size: 36,
                color:
                    Color(
                  0xFF0D5CC7,
                ),
              ),
            ),

            const SizedBox(
              height: 18,
            ),

            const Text(
              'Unable to load cart',

              textAlign:
                  TextAlign.center,

              style:
                  TextStyle(
                fontSize: 20,
                fontWeight:
                    FontWeight.w900,
                color:
                    Color(
                  0xFF102F4F,
                ),
              ),
            ),

            const SizedBox(
              height: 8,
            ),

            Text(
              message,

              textAlign:
                  TextAlign.center,

              style: TextStyle(
                fontSize: 13,
                height: 1.4,
                color:
                    Colors.grey
                        .shade600,
              ),
            ),

            const SizedBox(
              height: 20,
            ),

            SizedBox(
              height: 48,

              child:
                  ElevatedButton(
                onPressed:
                    onRetry,

                style:
                    ElevatedButton
                        .styleFrom(
                  backgroundColor:
                      const Color(
                    0xFF0D5CC7,
                  ),

                  foregroundColor:
                      Colors.white,

                  elevation: 0,

                  shape:
                      RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius
                            .circular(
                      13,
                    ),
                  ),
                ),

                child:
                    const Text(
                  'Try Again',

                  style:
                      TextStyle(
                    color:
                        Colors.white,
                    fontWeight:
                        FontWeight
                            .w800,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ====================================================================
// BOTTOM NAVIGATION
// ====================================================================

class _CartBottomNavigation
    extends StatelessWidget {
  const _CartBottomNavigation({
    required this.currentIndex,
    required this.onHome,
    required this.onCategories,
    required this.onCart,
    required this.onWishlist,
    required this.onProfile,
  });

  final int currentIndex;

  final VoidCallback onHome;
  final VoidCallback onCategories;
  final VoidCallback onCart;
  final VoidCallback onWishlist;
  final VoidCallback onProfile;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      decoration:
          const BoxDecoration(
        color: Colors.white,

        border: Border(
          top: BorderSide(
            color:
                Color(
              0xFFE8EDF3,
            ),
            width: 1,
          ),
        ),
      ),

      child: SafeArea(
        top: false,

        child: SizedBox(
          height: 68,

          child: Row(
            children: [
              // ====================================================
              // HOME
              // ====================================================

              Expanded(
                child: _NavItem(
                  icon:
                      Icons
                          .home_outlined,

                  activeIcon:
                      Icons
                          .home_rounded,

                  label: 'Home',

                  selected:
                      currentIndex ==
                          0,

                  onTap:
                      onHome,
                ),
              ),

              // ====================================================
              // CATEGORIES
              // ====================================================

              Expanded(
                child: _NavItem(
                  icon:
                      Icons
                          .grid_view_outlined,

                  activeIcon:
                      Icons
                          .grid_view_rounded,

                  label:
                      'Categories',

                  selected:
                      currentIndex ==
                          1,

                  onTap:
                      onCategories,
                ),
              ),

              // ====================================================
              // CART
              // ====================================================

              Expanded(
                child: _NavItem(
                  icon:
                      Icons
                          .shopping_bag_outlined,

                  activeIcon:
                      Icons
                          .shopping_bag_rounded,

                  label:
                      'Cart',

                  selected:
                      currentIndex ==
                          2,

                  onTap:
                      onCart,
                ),
              ),

              // ====================================================
              // WISHLIST
              // ====================================================

              Expanded(
                child: _NavItem(
                  icon:
                      Icons
                          .favorite_border_rounded,

                  activeIcon:
                      Icons
                          .favorite_rounded,

                  label:
                      'Wishlist',

                  selected:
                      currentIndex ==
                          3,

                  onTap:
                      onWishlist,
                ),
              ),

              // ====================================================
              // PROFILE
              // ====================================================

              Expanded(
                child: _NavItem(
                  icon:
                      Icons
                          .person_outline_rounded,

                  activeIcon:
                      Icons
                          .person_rounded,

                  label:
                      'Profile',

                  selected:
                      currentIndex ==
                          4,

                  onTap:
                      onProfile,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ====================================================================
// NAV ITEM
// ====================================================================

class _NavItem
    extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final IconData activeIcon;

  final String label;

  final bool selected;

  final VoidCallback onTap;

  static const Color primaryBlue =
      Color(0xFF0D5CC7);

  static const Color inactiveColor =
      Color(0xFFB7C1CC);

  @override
  Widget build(
    BuildContext context,
  ) {
    return InkWell(
      onTap: onTap,

      splashColor:
          primaryBlue.withValues(
        alpha: 0.06,
      ),

      highlightColor:
          primaryBlue.withValues(
        alpha: 0.03,
      ),

      child: Column(
        mainAxisAlignment:
            MainAxisAlignment
                .center,

        children: [
          Icon(
            selected
                ? activeIcon
                : icon,

            size: 23,

            color: selected
                ? primaryBlue
                : inactiveColor,
          ),

          const SizedBox(
            height: 4,
          ),

          Text(
            label,

            maxLines: 1,

            overflow:
                TextOverflow
                    .ellipsis,

            style: TextStyle(
              fontSize: 10.5,

              fontWeight:
                  selected
                      ? FontWeight
                          .w800
                      : FontWeight
                          .w500,

              color: selected
                  ? primaryBlue
                  : inactiveColor,
            ),
          ),
        ],
      ),
    );
  }
}