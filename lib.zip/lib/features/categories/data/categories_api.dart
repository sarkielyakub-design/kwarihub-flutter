import 'package:dio/dio.dart';

import '../../../core/network/api_client.dart';
import '../models/category_model.dart';

class CategoriesApi {
  CategoriesApi({
    ApiClient? apiClient,
  }) : _apiClient = apiClient ?? ApiClient.instance;

  final ApiClient _apiClient;

  // ============================================================
  // GET ALL CATEGORIES
  // ============================================================

  Future<List<CategoryModel>> getCategories() async {
    try {
      final response = await _apiClient.dio.get(
        '/categories',
      );

      final responseData = response.data;

      // ----------------------------------------------------------
      // VALIDATE RESPONSE
      // ----------------------------------------------------------

      if (responseData is! Map) {
        throw Exception(
          'Invalid categories response.',
        );
      }

      final data = Map<String, dynamic>.from(
        responseData,
      );

      // ----------------------------------------------------------
      // CHECK SUCCESS
      // ----------------------------------------------------------

      if (data['success'] != true) {
        throw Exception(
          data['message']?.toString() ??
              'Unable to load categories.',
        );
      }

      // ----------------------------------------------------------
      // GET CATEGORY DATA
      // ----------------------------------------------------------

      final categoriesData = data['data'];

      if (categoriesData is! List) {
        throw Exception(
          'Invalid categories data.',
        );
      }

      // ----------------------------------------------------------
      // PARSE CATEGORIES
      // ----------------------------------------------------------

      final categories = categoriesData
          .whereType<Map>()
          .map(
            (item) => CategoryModel.fromJson(
              Map<String, dynamic>.from(
                item,
              ),
            ),
          )
          .where(
            (category) => category.isActive,
          )
          .toList();

      return categories;
    }

    // ============================================================
    // DIO ERROR
    // ============================================================

    on DioException catch (e) {
      throw Exception(
        _handleDioError(
          e,
          fallback: 'Unable to load categories.',
        ),
      );
    }

    // ============================================================
    // OTHER ERROR
    // ============================================================

    catch (e) {
      throw Exception(
        e.toString().replaceFirst(
          'Exception: ',
          '',
        ),
      );
    }
  }

  // ============================================================
  // GET SINGLE CATEGORY
  // ============================================================

  Future<CategoryModel> getCategory(
    String uuid,
  ) async {
    try {
      final response = await _apiClient.dio.get(
        '/categories/$uuid',
      );

      final responseData = response.data;

      // ----------------------------------------------------------
      // VALIDATE RESPONSE
      // ----------------------------------------------------------

      if (responseData is! Map) {
        throw Exception(
          'Invalid category response.',
        );
      }

      final data = Map<String, dynamic>.from(
        responseData,
      );

      // ----------------------------------------------------------
      // PARSE CATEGORY
      // ----------------------------------------------------------

      return CategoryModel.fromJson(
        data,
      );
    }

    // ============================================================
    // DIO ERROR
    // ============================================================

    on DioException catch (e) {
      throw Exception(
        _handleDioError(
          e,
          fallback: 'Unable to load category.',
        ),
      );
    }

    // ============================================================
    // OTHER ERROR
    // ============================================================

    catch (e) {
      throw Exception(
        e.toString().replaceFirst(
          'Exception: ',
          '',
        ),
      );
    }
  }

  // ============================================================
  // ERROR HANDLER
  // ============================================================

  String _handleDioError(
    DioException error, {
    required String fallback,
  }) {
    // ----------------------------------------------------------
    // SERVER RESPONSE
    // ----------------------------------------------------------

    if (error.response != null) {
      final responseData =
          error.response?.data;

      if (responseData is Map) {
        final data =
            Map<String, dynamic>.from(
          responseData,
        );

        // FastAPI detail
        final detail = data['detail'];

        if (detail is String &&
            detail.isNotEmpty) {
          return detail;
        }

        // Generic message
        final message = data['message'];

        if (message is String &&
            message.isNotEmpty) {
          return message;
        }

        // Success false + message
        if (data['success'] == false) {
          return message?.toString() ??
              fallback;
        }
      }

      return '$fallback '
          'Status code: '
          '${error.response?.statusCode}';
    }

    // ----------------------------------------------------------
    // CONNECTION TIMEOUT
    // ----------------------------------------------------------

    switch (error.type) {
      case DioExceptionType.connectionTimeout:
        return 'Connection timed out. Please try again.';

      case DioExceptionType.sendTimeout:
        return 'Request timed out. Please try again.';

      case DioExceptionType.receiveTimeout:
        return 'Server response timed out. Please try again.';

      case DioExceptionType.transformTimeout:
        return 'Data transformation timed out. Please try again.';

      case DioExceptionType.connectionError:
        return 'Unable to connect to KwariHub server.';

      case DioExceptionType.badCertificate:
        return 'Secure connection failed.';

      case DioExceptionType.cancel:
        return 'Request was cancelled.';

      case DioExceptionType.badResponse:
        return fallback;

      case DioExceptionType.unknown:
        return 'Network error. Please try again.';
    }
  }
}