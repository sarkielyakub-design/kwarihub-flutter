class CategoryModel {
  final int id;
  final String uuid;
  final String name;
  final String slug;
  final String? description;
  final String? icon;
  final int? parentId;
  final int sortOrder;
  final bool isFeatured;
  final bool isActive;

  const CategoryModel({
    required this.id,
    required this.uuid,
    required this.name,
    required this.slug,
    required this.description,
    required this.icon,
    required this.parentId,
    required this.sortOrder,
    required this.isFeatured,
    required this.isActive,
  });

  factory CategoryModel.fromJson(
    Map<String, dynamic> json,
  ) {
    return CategoryModel(
      id: _toInt(json['id']),
      uuid: json['uuid']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      description: json['description']?.toString(),
      icon: json['icon']?.toString(),
      parentId: json['parent_id'] == null
          ? null
          : _toInt(json['parent_id']),
      sortOrder: _toInt(json['sort_order']),
      isFeatured: json['is_featured'] == true,
      isActive: json['is_active'] == true,
    );
  }

  static int _toInt(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value.toString()) ?? 0;
  }
}