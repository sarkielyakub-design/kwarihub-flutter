import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kwarihub/features/auth/presentation/login_screen.dart';

import '../models/category_model.dart';
import '../providers/categories_provider.dart';

// ================================================================
// COLORS
// ================================================================

const Color primaryBlue = Color(0xFF0D5CC7);
const Color darkBlue = Color(0xFF102F4F);
const Color lightBlue = Color(0xFFF4F8FF);
const Color borderColor = Color(0xFFDDE6F0);
const Color softBackground = Color(0xFFFAFCFF);

class CategoriesScreen extends ConsumerStatefulWidget {
  const CategoriesScreen({
    super.key,
    this.categoryId,
  });

  /// Optional category UUID.
  ///
  /// Used when the route is:
  /// /categories/:id
  final String? categoryId;

  @override
  ConsumerState<CategoriesScreen> createState() =>
      _CategoriesScreenState();
}

class _CategoriesScreenState
    extends ConsumerState<CategoriesScreen> {
  // ============================================================
  // SEARCH
  // ============================================================

  final TextEditingController _searchController =
      TextEditingController();

  String _searchQuery = '';

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // ============================================================
  // REFRESH
  // ============================================================

  Future<void> _refresh() async {
    ref.invalidate(categoriesProvider);

    await ref.read(
      categoriesProvider.future,
    );
  }

  // ============================================================
  // SEARCH
  // ============================================================

  List<CategoryModel> _filterCategories(
    List<CategoryModel> categories,
  ) {
    final query = _searchQuery
        .trim()
        .toLowerCase();

    if (query.isEmpty) {
      return categories;
    }

    return categories.where(
      (category) {
        final name =
            category.name.toLowerCase();

        final slug =
            category.slug.toLowerCase();

        final description =
            category.description
                    ?.toLowerCase() ??
                '';

        return name.contains(query) ||
            slug.contains(query) ||
            description.contains(query);
      },
    ).toList();
  }

  // ============================================================
  // SELECTED CATEGORY
  // ============================================================

  CategoryModel? _findSelectedCategory(
    List<CategoryModel> categories,
  ) {
    final categoryId =
        widget.categoryId;

    if (categoryId == null ||
        categoryId.trim().isEmpty) {
      return null;
    }

    for (final category in categories) {
      if (category.uuid == categoryId) {
        return category;
      }
    }

    return null;
  }

  // ============================================================
  // OPEN CATEGORY
  // ============================================================

  void _openCategory(
    CategoryModel category,
  ) {
    if (category.uuid.trim().isEmpty) {
      return;
    }

    context.push(
      '/categories/${category.uuid}',
    );
  }

  // ============================================================
  // BACK
  // ============================================================

  void _goBack() {
    if (context.canPop()) {
      context.pop();
      return;
    }

    context.go('/home');
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    final categoriesAsync =
        ref.watch(categoriesProvider);

    return Scaffold(
      backgroundColor: Colors.white,

      body: SafeArea(
        child: categoriesAsync.when(
          // ======================================================
          // LOADING
          // ======================================================

          loading: () {
            return const _CategoriesLoading();
          },

          // ======================================================
          // ERROR
          // ======================================================

          error: (
            error,
            stackTrace,
          ) {
            return _CategoriesError(
              message: error
                  .toString()
                  .replaceFirst(
                    'Exception: ',
                    '',
                  ),
              onRetry: () {
                ref.invalidate(
                  categoriesProvider,
                );
              },
            );
          },

          // ======================================================
          // DATA
          // ======================================================

          data: (
            categories,
          ) {
            final filteredCategories =
                _filterCategories(
              categories,
            );

            final selectedCategory =
                _findSelectedCategory(
              categories,
            );

            return RefreshIndicator(
              color: primaryBlue,
              onRefresh: _refresh,

              child: CustomScrollView(
                physics:
                    const AlwaysScrollableScrollPhysics(
                  parent:
                      BouncingScrollPhysics(),
                ),

                slivers: [
                  // ==================================================
                  // HEADER
                  // ==================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        12,
                        24,
                        0,
                      ),

                      child: Row(
                        children: [
                          IconButton(
                            onPressed:
                                _goBack,

                            tooltip:
                                'Back',

                            icon:
                                const Icon(
                              Icons
                                  .arrow_back_rounded,
                              color:
                                  darkBlue,
                            ),
                          ),

                          const SizedBox(
                            width: 2,
                          ),

                          const Expanded(
                            child: Text(
                              'Categories',

                              style:
                                  TextStyle(
                                fontSize: 24,
                                fontWeight:
                                    FontWeight
                                        .w900,
                                color:
                                    darkBlue,
                              ),
                            ),
                          ),

                          Image.asset(
                            'assets/images/kwarihub_logo.png',

                            width: 92,
                            height: 36,

                            fit:
                                BoxFit.contain,
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ==================================================
                  // SUBTITLE
                  // ==================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        4,
                        24,
                        0,
                      ),

                      child: Text(
                        selectedCategory !=
                                null
                            ? 'Explore ${selectedCategory.name}.'
                            : 'Explore our textile and fashion categories.',

                        style:
                            TextStyle(
                          fontSize: 13,
                          height: 1.4,
                          color:
                              Colors.grey
                                  .shade600,
                        ),
                      ),
                    ),
                  ),

                  // ==================================================
                  // SELECTED CATEGORY
                  // ==================================================

                  if (selectedCategory !=
                      null)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding:
                            const EdgeInsets.fromLTRB(
                          24,
                          18,
                          24,
                          0,
                        ),

                        child:
                            _SelectedCategoryCard(
                          category:
                              selectedCategory,

                          onTap: () {
                            // Product/category detail
                            // will be connected to
                            // the real backend endpoint.
                          },
                        ),
                      ),
                    ),

                  // ==================================================
                  // SEARCH
                  // ==================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        18,
                        24,
                        0,
                      ),

                      child:
                          _buildSearchBar(),
                    ),
                  ),

                  // ==================================================
                  // FEATURED TITLE
                  // ==================================================

                  if (_searchQuery
                          .trim()
                          .isEmpty &&
                      categories.any(
                        (category) =>
                            category.isFeatured,
                      ))
                    SliverToBoxAdapter(
                      child: Padding(
                        padding:
                            const EdgeInsets.fromLTRB(
                          24,
                          25,
                          24,
                          0,
                        ),

                        child: const Text(
                          'Featured Categories',

                          style:
                              TextStyle(
                            fontSize: 20,
                            fontWeight:
                                FontWeight.w900,
                            color:
                                darkBlue,
                          ),
                        ),
                      ),
                    ),

                  // ==================================================
                  // FEATURED CATEGORIES
                  // ==================================================

                  if (_searchQuery
                          .trim()
                          .isEmpty &&
                      categories.any(
                        (category) =>
                            category.isFeatured,
                      ))
                    SliverToBoxAdapter(
                      child:
                          _buildFeaturedCategories(
                        categories
                            .where(
                              (category) =>
                                  category
                                      .isFeatured,
                            )
                            .toList(),
                      ),
                    ),

                  // ==================================================
                  // ALL CATEGORIES HEADER
                  // ==================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        25,
                        24,
                        0,
                      ),

                      child: Text(
                        _searchQuery
                                .trim()
                                .isEmpty
                            ? 'All Categories'
                            : 'Search Results',

                        style:
                            const TextStyle(
                          fontSize: 20,
                          fontWeight:
                              FontWeight.w900,
                          color:
                              darkBlue,
                        ),
                      ),
                    ),
                  ),

                  // ==================================================
                  // CATEGORY COUNT
                  // ==================================================

                  if (filteredCategories
                      .isNotEmpty)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding:
                            const EdgeInsets.fromLTRB(
                          24,
                          5,
                          24,
                          0,
                        ),

                        child: Text(
                          '${filteredCategories.length} ${filteredCategories.length == 1 ? 'category' : 'categories'}',

                          style:
                              TextStyle(
                            fontSize: 11,
                            color:
                                Colors.grey
                                    .shade500,
                            fontWeight:
                                FontWeight.w500,
                          ),
                        ),
                      ),
                    ),

                  // ==================================================
                  // EMPTY
                  // ==================================================

                  if (filteredCategories
                      .isEmpty)
                    const SliverToBoxAdapter(
                      child: Padding(
                        padding:
                            EdgeInsets.fromLTRB(
                          24,
                          18,
                          24,
                          30,
                        ),

                        child:
                            _EmptyCategories(),
                      ),
                    ),

                  // ==================================================
                  // CATEGORY GRID
                  // ==================================================

                  if (filteredCategories
                      .isNotEmpty)
                    SliverPadding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        16,
                        24,
                        30,
                      ),

                      sliver:
                          SliverGrid(
                        delegate:
                            SliverChildBuilderDelegate(
                          (
                            context,
                            index,
                          ) {
                            final category =
                                filteredCategories[
                                    index];

                            return _CategoryGridCard(
                              category:
                                  category,

                              onTap: () {
                                _openCategory(
                                  category,
                                );
                              },
                            );
                          },

                          childCount:
                              filteredCategories
                                  .length,
                        ),

                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 14,
                          mainAxisSpacing: 16,
                          childAspectRatio: 0.88,
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),

      // ==========================================================
      // BOTTOM NAVIGATION
      // ==========================================================

      bottomNavigationBar:
          _buildBottomNavigation(),
    );
  }

  // ============================================================
  // SEARCH BAR
  // ============================================================

  Widget _buildSearchBar() {
    return Container(
      height: 52,

      decoration:
          BoxDecoration(
        color: softBackground,

        borderRadius:
            BorderRadius.circular(
          15,
        ),

        border:
            Border.all(
          color:
              borderColor,
        ),
      ),

      child: Row(
        children: [
          const SizedBox(
            width: 15,
          ),

          Icon(
            Icons.search_rounded,
            size: 22,
            color:
                Colors.grey.shade500,
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: TextField(
              controller:
                  _searchController,

              onChanged: (
                value,
              ) {
                setState(() {
                  _searchQuery =
                      value;
                });
              },

              textInputAction:
                  TextInputAction.search,

              decoration:
                  const InputDecoration(
                border:
                    InputBorder.none,

                hintText:
                    'Search categories...',

                isDense: true,

                contentPadding:
                    EdgeInsets.zero,
              ),

              style:
                  const TextStyle(
                fontSize: 14,
                color: darkBlue,
                fontWeight:
                    FontWeight.w500,
              ),
            ),
          ),

          if (_searchQuery
              .isNotEmpty)
            IconButton(
              onPressed: () {
                _searchController
                    .clear();

                setState(() {
                  _searchQuery =
                      '';
                });
              },

              icon:
                  Icon(
                Icons.close_rounded,
                size: 19,
                color:
                    Colors.grey.shade500,
              ),
            ),

          const SizedBox(
            width: 3,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // FEATURED CATEGORIES
  // ============================================================

  Widget _buildFeaturedCategories(
    List<CategoryModel> categories,
  ) {
    if (categories.isEmpty) {
      return const SizedBox.shrink();
    }

    return SizedBox(
      height: 150,

      child:
          ListView.separated(
        padding:
            const EdgeInsets.fromLTRB(
          24,
          14,
          24,
          0,
        ),

        scrollDirection:
            Axis.horizontal,

        physics:
            const BouncingScrollPhysics(),

        itemCount:
            categories.length,

        separatorBuilder:
            (_, __) {
          return const SizedBox(
            width: 14,
          );
        },

        itemBuilder:
            (
          context,
          index,
        ) {
          final category =
              categories[index];

          return _FeaturedCategoryCard(
            category:
                category,

            onTap: () {
              _openCategory(
                category,
              );
            },
          );
        },
      ),
    );
  }

  // ============================================================
  // BOTTOM NAVIGATION
  // ============================================================

  Widget _buildBottomNavigation() {
    return Container(
      decoration:
          BoxDecoration(
        color:
            Colors.white,

        border:
            Border(
          top:
              BorderSide(
            color:
                borderColor
                    .withOpacity(
              0.7,
            ),
          ),
        ),
      ),

      child:
          SafeArea(
        top: false,

        child:
            Padding(
          padding:
              const EdgeInsets
                  .symmetric(
            horizontal: 8,
            vertical: 7,
          ),

          child:
              Row(
            mainAxisAlignment:
                MainAxisAlignment
                    .spaceAround,

            children: [
              _BottomNavItem(
                icon:
                    Icons.home_rounded,

                label:
                    'Home',

                selected:
                    false,

                onTap: () {
                  context.go(
                    '/home',
                  );
                },
              ),

              _BottomNavItem(
                icon:
                    Icons.grid_view_rounded,

                label:
                    'Categories',

                selected:
                    true,

                onTap: () {},
              ),

              _BottomNavItem(
                icon:
                    Icons.shopping_bag_outlined,

                label:
                    'Cart',

                selected:
                    false,

                onTap: () {
                  context.go(
                    '/cart',
                  );
                },
              ),

              _BottomNavItem(
                icon:
                    Icons.favorite_border_rounded,

                label:
                    'Wishlist',

                selected:
                    false,

                onTap: () {
                  context.go(
                    '/wishlist',
                  );
                },
              ),

              _BottomNavItem(
                icon:
                    Icons.person_outline_rounded,

                label:
                    'Profile',

                selected:
                    false,

                onTap: () {
                  context.go(
                    '/profile',
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================================================================
// SELECTED CATEGORY CARD
// ================================================================

class _SelectedCategoryCard
    extends StatelessWidget {
  const _SelectedCategoryCard({
    required this.category,
    required this.onTap,
  });

  final CategoryModel category;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: onTap,

      child: Container(
        width:
            double.infinity,

        padding:
            const EdgeInsets.all(
          16,
        ),

        decoration:
            BoxDecoration(
          color:
              lightBlue,

          borderRadius:
              BorderRadius.circular(
            18,
          ),

          border:
              Border.all(
            color:
                const Color(
              0xFFD7E6F8,
            ),
          ),
        ),

        child:
            Row(
          children: [
            SizedBox(
              width: 70,
              height: 70,

              child:
                  _CategoryImage(
                icon:
                    category.icon,
              ),
            ),

            const SizedBox(
              width: 14,
            ),

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment
                        .start,

                children: [
                  Text(
                    category.name,

                    maxLines: 1,

                    overflow:
                        TextOverflow
                            .ellipsis,

                    style:
                        const TextStyle(
                      fontSize: 17,
                      fontWeight:
                          FontWeight.w900,
                      color:
                          darkBlue,
                    ),
                  ),

                  if (category
                          .description !=
                      null &&
                      category.description!
                          .trim()
                          .isNotEmpty)
                    Padding(
                      padding:
                          const EdgeInsets
                              .only(
                        top: 5,
                      ),

                      child:
                          Text(
                        category
                            .description!,

                        maxLines:
                            2,

                        overflow:
                            TextOverflow
                                .ellipsis,

                        style:
                            TextStyle(
                          fontSize: 11,
                          height: 1.35,
                          color:
                              Colors.grey
                                  .shade600,
                        ),
                      ),
                    ),

                  const SizedBox(
                    height: 8,
                  ),

                  const Text(
                    'Category selected',

                    style:
                        TextStyle(
                      fontSize: 10,
                      fontWeight:
                          FontWeight.w700,
                      color:
                          primaryBlue,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(
              width: 8,
            ),

            const Icon(
              Icons
                  .chevron_right_rounded,

              color:
                  primaryBlue,

              size: 24,
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// FEATURED CATEGORY CARD
// ================================================================

class _FeaturedCategoryCard
    extends StatelessWidget {
  const _FeaturedCategoryCard({
    required this.category,
    required this.onTap,
  });

  final CategoryModel category;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: onTap,

      child: Container(
        width: 145,

        padding:
            const EdgeInsets.all(
          12,
        ),

        decoration:
            BoxDecoration(
          color:
              softBackground,

          borderRadius:
              BorderRadius.circular(
            18,
          ),

          border:
              Border.all(
            color:
                const Color(
              0xFFEAF0F6,
            ),
          ),
        ),

        child:
            Column(
          crossAxisAlignment:
              CrossAxisAlignment
                  .start,

          children: [
            Expanded(
              child:
                  _CategoryImage(
                icon:
                    category.icon,
              ),
            ),

            const SizedBox(
              height: 8,
            ),

            Text(
              category.name,

              maxLines: 1,

              overflow:
                  TextOverflow.ellipsis,

              style:
                  const TextStyle(
                fontSize: 13,
                fontWeight:
                    FontWeight.w800,
                color:
                    darkBlue,
              ),
            ),

            const SizedBox(
              height: 2,
            ),

            Row(
              children: [
                const Text(
                  'Explore',

                  style:
                      TextStyle(
                    fontSize: 10,
                    fontWeight:
                        FontWeight.w600,
                    color:
                        primaryBlue,
                  ),
                ),

                const SizedBox(
                  width: 3,
                ),

                const Icon(
                  Icons
                      .arrow_forward_rounded,

                  size: 11,

                  color:
                      primaryBlue,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// CATEGORY GRID CARD
// ================================================================

class _CategoryGridCard
    extends StatelessWidget {
  const _CategoryGridCard({
    required this.category,
    required this.onTap,
  });

  final CategoryModel category;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: onTap,

      child:
          Container(
        padding:
            const EdgeInsets.all(
          12,
        ),

        decoration:
            BoxDecoration(
          color:
              Colors.white,

          borderRadius:
              BorderRadius.circular(
            18,
          ),

          border:
              Border.all(
            color:
                const Color(
              0xFFEAF0F6,
            ),
          ),

          boxShadow: [
            BoxShadow(
              color:
                  Colors.black
                      .withOpacity(
                0.025,
              ),

              blurRadius:
                  10,

              offset:
                  const Offset(
                0,
                4,
              ),
            ),
          ],
        ),

        child:
            Column(
          crossAxisAlignment:
              CrossAxisAlignment
                  .start,

          children: [
            Expanded(
              child:
                  _CategoryImage(
                icon:
                    category.icon,
              ),
            ),

            const SizedBox(
              height: 10,
            ),

            Text(
              category.name,

              maxLines: 1,

              overflow:
                  TextOverflow.ellipsis,

              style:
                  const TextStyle(
                fontSize: 14,
                fontWeight:
                    FontWeight.w800,
                color:
                    darkBlue,
              ),
            ),

            if (category
                    .description !=
                null &&
                category.description!
                    .trim()
                    .isNotEmpty)
              Padding(
                padding:
                    const EdgeInsets
                        .only(
                  top: 3,
                ),

                child:
                    Text(
                  category
                      .description!,

                  maxLines: 2,

                  overflow:
                      TextOverflow
                          .ellipsis,

                  style:
                      TextStyle(
                    fontSize: 10,
                    height: 1.25,
                    color:
                        Colors.grey
                            .shade600,
                  ),
                ),
              ),

            const SizedBox(
              height: 7,
            ),

            Row(
              children: [
                const Text(
                  'View',

                  style:
                      TextStyle(
                    fontSize: 10,
                    fontWeight:
                        FontWeight.w700,
                    color:
                        primaryBlue,
                  ),
                ),

                const SizedBox(
                  width: 3,
                ),

                const Icon(
                  Icons
                      .arrow_forward_rounded,

                  size: 12,

                  color:
                      primaryBlue,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// CATEGORY IMAGE
// ================================================================

class _CategoryImage
    extends StatelessWidget {
  const _CategoryImage({
    required this.icon,
  });

  final String? icon;

  @override
  Widget build(
    BuildContext context,
  ) {
    final value =
        icon?.trim();

    if (value == null ||
        value.isEmpty) {
      return _fallback();
    }

    final isNetworkImage =
        value.startsWith(
              'http://',
            ) ||
            value.startsWith(
              'https://',
            );

    if (!isNetworkImage) {
      // The backend may currently return
      // a filename such as:
      //
      // shadda-fabrics.png
      //
      // We intentionally do not invent
      // a media URL here.

      return _fallback();
    }

    return ClipRRect(
      borderRadius:
          BorderRadius.circular(
        14,
      ),

      child:
          Image.network(
        value,

        width:
            double.infinity,

        height:
            double.infinity,

        fit:
            BoxFit.cover,

        loadingBuilder:
            (
          context,
          child,
          loadingProgress,
        ) {
          if (loadingProgress ==
              null) {
            return child;
          }

          return _imageLoading();
        },

        errorBuilder:
            (
          context,
          error,
          stackTrace,
        ) {
          return _fallback();
        },
      ),
    );
  }

  Widget _imageLoading() {
    return Container(
      width:
          double.infinity,

      height:
          double.infinity,

      decoration:
          BoxDecoration(
        color:
            lightBlue,

        borderRadius:
            BorderRadius.circular(
          14,
        ),
      ),

      child:
          const Center(
        child:
            SizedBox(
          width: 20,
          height: 20,

          child:
              CircularProgressIndicator(
            strokeWidth: 2,

            color:
                primaryBlue,
          ),
        ),
      ),
    );
  }

  Widget _fallback() {
    return Container(
      width:
          double.infinity,

      height:
          double.infinity,

      decoration:
          BoxDecoration(
        color:
            lightBlue,

        borderRadius:
            BorderRadius.circular(
          14,
        ),
      ),

      child:
          const Center(
        child:
            Icon(
          Icons
              .checkroom_outlined,

          size:
              38,

          color:
              primaryBlue,
        ),
      ),
    );
  }
}

// ================================================================
// BOTTOM NAV ITEM
// ================================================================

class _BottomNavItem
    extends StatelessWidget {
  const _BottomNavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: onTap,

      behavior:
          HitTestBehavior.opaque,

      child:
          SizedBox(
        width:
            65,

        child:
            Column(
          mainAxisSize:
              MainAxisSize.min,

          children: [
            Icon(
              icon,

              size:
                  24,

              color:
                  selected
                      ? primaryBlue
                      : Colors
                          .grey
                          .shade400,
            ),

            const SizedBox(
              height: 4,
            ),

            Text(
              label,

              maxLines:
                  1,

              overflow:
                  TextOverflow
                      .ellipsis,

              style:
                  TextStyle(
                fontSize:
                    10,

                fontWeight:
                    selected
                        ? FontWeight
                            .w700
                        : FontWeight
                            .w500,

                color:
                    selected
                        ? primaryBlue
                        : Colors
                            .grey
                            .shade400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// LOADING
// ================================================================

class _CategoriesLoading
    extends StatelessWidget {
  const _CategoriesLoading();

  @override
  Widget build(
    BuildContext context,
  ) {
    return const Center(
      child:
          CircularProgressIndicator(
        color:
            primaryBlue,
      ),
    );
  }
}

// ================================================================
// ERROR
// ================================================================

class _CategoriesError
    extends StatelessWidget {
  const _CategoriesError({
    required this.message,
    required this.onRetry,
  });

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Center(
      child:
          SingleChildScrollView(
        padding:
            const EdgeInsets.all(
          24,
        ),

        child:
            Column(
          mainAxisAlignment:
              MainAxisAlignment
                  .center,

          children: [
            Container(
              width:
                  72,

              height:
                  72,

              decoration:
                  BoxDecoration(
                color:
                    lightBlue,

                borderRadius:
                    BorderRadius
                        .circular(
                  20,
                ),
              ),

              child:
                  const Icon(
                Icons
                    .cloud_off_rounded,

                color:
                    primaryBlue,

                size:
                    34,
              ),
            ),

            const SizedBox(
              height:
                  18,
            ),

            const Text(
              'Unable to load categories',

              textAlign:
                  TextAlign.center,

              style:
                  TextStyle(
                fontSize:
                    19,

                fontWeight:
                    FontWeight
                        .w800,

                color:
                    darkBlue,
              ),
            ),

            const SizedBox(
              height:
                  8,
            ),

            Text(
              message.isEmpty
                  ? 'Something went wrong while loading categories.'
                  : message,

              textAlign:
                  TextAlign.center,

              style:
                  TextStyle(
                fontSize:
                    13,

                height:
                    1.4,

                color:
                    Colors
                        .grey
                        .shade600,
              ),
            ),

            const SizedBox(
              height:
                  20,
            ),

            SizedBox(
              height:
                  48,

              child:
                  ElevatedButton(
                onPressed:
                    onRetry,

                style:
                    ElevatedButton
                        .styleFrom(
                  backgroundColor:
                      primaryBlue,

                  foregroundColor:
                      Colors.white,

                  elevation:
                      0,

                  padding:
                      const EdgeInsets
                          .symmetric(
                    horizontal:
                        24,
                  ),

                  shape:
                      RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius
                            .circular(
                      13,
                    ),
                  ),
                ),

                child:
                    const Text(
                  'Try Again',

                  style:
                      TextStyle(
                    color:
                        Colors.white,

                    fontWeight:
                        FontWeight
                            .w800,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// EMPTY
// ================================================================

class _EmptyCategories
    extends StatelessWidget {
  const _EmptyCategories();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        24,
      ),

      decoration:
          BoxDecoration(
        color:
            softBackground,

        borderRadius:
            BorderRadius.circular(
          16,
        ),

        border:
            Border.all(
          color:
              const Color(
            0xFFEAF0F6,
          ),
        ),
      ),

      child:
          Column(
        children: [
          Container(
            width:
                64,

            height:
                64,

            decoration:
                BoxDecoration(
              color:
                  lightBlue,

              borderRadius:
                  BorderRadius
                      .circular(
                18,
              ),
            ),

            child:
                const Icon(
              Icons
                  .search_off_rounded,

              color:
                  primaryBlue,

              size:
                  32,
            ),
          ),

          const SizedBox(
            height:
                12,
          ),

          const Text(
            'No categories found',

            style:
                TextStyle(
              fontSize:
                  15,

              fontWeight:
                  FontWeight
                      .w700,

              color:
                  darkBlue,
            ),
          ),

          const SizedBox(
            height:
                5,
          ),

          Text(
            'Try another search term.',

            textAlign:
                TextAlign.center,

            style:
                TextStyle(
              fontSize:
                  12,

              color:
                  Colors
                      .grey
                      .shade600,
            ),
          ),
        ],
      ),
    );
  }
}