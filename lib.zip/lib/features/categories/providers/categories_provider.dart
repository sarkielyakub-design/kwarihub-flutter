import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/categories_api.dart';
import '../models/category_model.dart';

final categoriesApiProvider = Provider<CategoriesApi>(
  (ref) => CategoriesApi(),
);

final categoriesProvider =
    FutureProvider.autoDispose<List<CategoryModel>>(
  (ref) async {
    final api = ref.read(
      categoriesApiProvider,
    );

    return api.getCategories();
  },
);