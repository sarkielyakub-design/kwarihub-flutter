import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../models/dashboard_model.dart';
import '../providers/dashboard_provider.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() =>
      _DashboardScreenState();
}

class _DashboardScreenState
    extends ConsumerState<DashboardScreen> {
  // ============================================================
  // COLORS
  // ============================================================

  static const Color primaryBlue = Color(0xFF0D5CC7);
  static const Color darkBlue = Color(0xFF102F4F);
  static const Color borderColor = Color(0xFFDDE6F0);

  // ============================================================
  // CONTROLLER
  // ============================================================

  final TextEditingController _searchController =
      TextEditingController();

  // ============================================================
  // STATE
  // ============================================================

  bool _isSearching = false;

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // ============================================================
  // REFRESH
  // ============================================================

  Future<void> _refresh() async {
    ref.invalidate(dashboardProvider);

    await ref.read(dashboardProvider.future);
  }

  // ============================================================
  // NOTIFICATIONS
  // ============================================================

  void _openNotifications() {
    context.push('/notifications');
  }

  // ============================================================
  // SEARCH
  // ============================================================

  void _openSearch() {
    if (!_isSearching) {
      setState(() {
        _isSearching = true;
      });
    }
  }

  void _performSearch() {
    final query = _searchController.text.trim();

    if (query.isEmpty) {
      return;
    }

    FocusScope.of(context).unfocus();

    /*
     * IMPORTANT:
     * Search should be connected to the real backend search
     * endpoint when the search API/provider is available.
     *
     * We are intentionally NOT creating mock search results here.
     */
    debugPrint('Search requested: $query');
  }

  // ============================================================
  // NAVIGATION
  // ============================================================

  void _openCategories() {
    context.go('/categories');
  }

  void _openCart() {
    context.go('/cart');
  }

  void _openWishlist() {
    context.go('/wishlist');
  }

  void _openProfile() {
    context.go('/profile');
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final dashboardAsync = ref.watch(dashboardProvider);

    return Scaffold(
      backgroundColor: Colors.white,

      body: SafeArea(
        child: dashboardAsync.when(
          // ------------------------------------------------------
          // LOADING
          // ------------------------------------------------------

          loading: () => const _DashboardLoading(),

          // ------------------------------------------------------
          // ERROR
          // ------------------------------------------------------

          error: (error, stackTrace) {
            return _DashboardError(
              message: error
                  .toString()
                  .replaceFirst(
                    'Exception: ',
                    '',
                  ),
              onRetry: () {
                ref.invalidate(
                  dashboardProvider,
                );
              },
            );
          },

          // ------------------------------------------------------
          // DATA
          // ------------------------------------------------------

          data: (dashboard) {
            return RefreshIndicator(
              color: primaryBlue,

              onRefresh: _refresh,

              child: _buildDashboard(
                dashboard,
              ),
            );
          },
        ),
      ),

      bottomNavigationBar:
          _buildBottomNavigation(),
    );
  }

  // ============================================================
  // DASHBOARD
  // ============================================================

  Widget _buildDashboard(
    DashboardModel dashboard,
  ) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },

      child: CustomScrollView(
        physics:
            const AlwaysScrollableScrollPhysics(
          parent: BouncingScrollPhysics(),
        ),

        slivers: [
          // ======================================================
          // HEADER
          // ======================================================

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(
                24,
                18,
                24,
                0,
              ),

              child: Row(
                children: [
                  Image.asset(
                    'assets/images/kwarihub_logo.png',
                    width: 112,
                    height: 42,
                    fit: BoxFit.contain,
                  ),

                  const Spacer(),

                  _HeaderIconButton(
                    icon:
                        Icons.notifications_none_rounded,
                    badge:
                        dashboard
                            .stats
                            .unreadNotifications,
                    onPressed:
                        _openNotifications,
                  ),
                ],
              ),
            ),
          ),

          // ======================================================
          // GREETING
          // ======================================================

          SliverToBoxAdapter(
            child: Padding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                17,
                24,
                0,
              ),

              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [
                  Text(
                    'Good morning 👋',
                    style: TextStyle(
                      fontSize: 14,
                      color:
                          Colors.grey.shade600,
                      fontWeight:
                          FontWeight.w500,
                    ),
                  ),

                  const SizedBox(height: 4),

                  Text(
                    dashboard
                        .user
                        .firstNameDisplay,
                    maxLines: 1,
                    overflow:
                        TextOverflow.ellipsis,

                    style:
                        const TextStyle(
                      fontSize: 22,
                      fontWeight:
                          FontWeight.w900,
                      color: darkBlue,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ======================================================
          // SEARCH
          // ======================================================

          SliverToBoxAdapter(
            child: Padding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                16,
                24,
                0,
              ),

              child: _buildSearchBar(),
            ),
          ),

          // ======================================================
          // QUICK STATS
          //
          // No wallet.
          // ======================================================

          SliverToBoxAdapter(
            child: Padding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                18,
                24,
                0,
              ),

              child: _buildQuickStats(
                dashboard.stats,
              ),
            ),
          ),

          // ======================================================
          // PROMOTIONAL BANNER
          // ======================================================

          SliverToBoxAdapter(
            child: Padding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                22,
                24,
                0,
              ),

              child: _buildBanner(),
            ),
          ),

          // ======================================================
          // CATEGORIES HEADER
          // ======================================================

          SliverToBoxAdapter(
            child: Padding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                27,
                24,
                0,
              ),

              child: _SectionHeader(
                title: 'Categories',
                action: 'See All',
                onTap:
                    _openCategories,
              ),
            ),
          ),

          // ======================================================
          // CATEGORIES
          // ======================================================

          SliverToBoxAdapter(
            child: _buildCategories(
              dashboard.featuredCategories,
            ),
          ),

          // ======================================================
          // FEATURED PRODUCTS HEADER
          // ======================================================

          SliverToBoxAdapter(
            child: Padding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                24,
                24,
                0,
              ),

              child: _SectionHeader(
                title: 'Featured Products',
                action: 'See All',
                onTap: () {
                  /*
                   * Product listing route will be connected
                   * when the product listing screen is ready.
                   *
                   * No mock navigation is added here.
                   */
                },
              ),
            ),
          ),

          // ======================================================
          // FEATURED PRODUCTS
          // ======================================================

          if (dashboard
              .featuredProducts
              .isNotEmpty)
            SliverPadding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                14,
                24,
                0,
              ),

              sliver: SliverGrid(
                delegate:
                    SliverChildBuilderDelegate(
                  (context, index) {
                    final product =
                        dashboard
                            .featuredProducts[
                                index];

                    return _ProductCard(
                      product: product,
                      onTap: () {
                        _openProduct(
                          product,
                        );
                      },
                    );
                  },

                  childCount:
                      dashboard
                          .featuredProducts
                          .length,
                ),

                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 18,
                  childAspectRatio: 0.68,
                ),
              ),
            ),

          // ======================================================
          // EMPTY FEATURED PRODUCTS
          // ======================================================

          if (dashboard
              .featuredProducts
              .isEmpty)
            const SliverToBoxAdapter(
              child: _EmptySection(
                message:
                    'No featured products available yet.',
              ),
            ),

          // ======================================================
          // LATEST PRODUCTS HEADER
          // ======================================================

          SliverToBoxAdapter(
            child: Padding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                27,
                24,
                0,
              ),

              child: _SectionHeader(
                title: 'Latest Products',
                action: 'See All',
                onTap: () {
                  /*
                   * Product listing route will be connected
                   * when the product listing screen is ready.
                   */
                },
              ),
            ),
          ),

          // ======================================================
          // LATEST PRODUCTS
          // ======================================================

          if (dashboard
              .latestProducts
              .isNotEmpty)
            SliverPadding(
              padding:
                  const EdgeInsets.fromLTRB(
                24,
                14,
                24,
                30,
              ),

              sliver: SliverGrid(
                delegate:
                    SliverChildBuilderDelegate(
                  (context, index) {
                    final product =
                        dashboard
                            .latestProducts[
                                index];

                    return _ProductCard(
                      product: product,
                      onTap: () {
                        _openProduct(
                          product,
                        );
                      },
                    );
                  },

                  childCount:
                      dashboard
                          .latestProducts
                          .length,
                ),

                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 18,
                  childAspectRatio: 0.68,
                ),
              ),
            ),

          // ======================================================
          // EMPTY LATEST PRODUCTS
          // ======================================================

          if (dashboard
              .latestProducts
              .isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding:
                    EdgeInsets.fromLTRB(
                  24,
                  14,
                  24,
                  30,
                ),

                child: _EmptySection(
                  message:
                      'No products available yet.',
                ),
              ),
            ),

          // ======================================================
          // RECENT ORDERS
          // ======================================================

          if (dashboard
              .recentOrders
              .isNotEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding:
                    const EdgeInsets.fromLTRB(
                  24,
                  0,
                  24,
                  30,
                ),

                child: _RecentOrders(
                  orders:
                      dashboard.recentOrders,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // SEARCH BAR
  // ============================================================

  Widget _buildSearchBar() {
    return AnimatedContainer(
      duration:
          const Duration(milliseconds: 200),

      height: 52,

      decoration: BoxDecoration(
        color: const Color(0xFFFAFCFF),

        borderRadius:
            BorderRadius.circular(15),

        border: Border.all(
          color: _isSearching
              ? primaryBlue
              : borderColor,

          width:
              _isSearching ? 1.4 : 1,
        ),
      ),

      child: Row(
        children: [
          const SizedBox(width: 15),

          Icon(
            Icons.search_rounded,
            size: 22,
            color:
                Colors.grey.shade500,
          ),

          const SizedBox(width: 10),

          Expanded(
            child: TextField(
              controller:
                  _searchController,

              onTap: _openSearch,

              onChanged: (_) {
                setState(() {});
              },

              onSubmitted: (_) {
                _performSearch();
              },

              textInputAction:
                  TextInputAction.search,

              decoration:
                  const InputDecoration(
                border: InputBorder.none,
                hintText:
                    'Search textiles, shops...',
                isDense: true,
              ),

              style:
                  const TextStyle(
                fontSize: 14,
                color: darkBlue,
                fontWeight:
                    FontWeight.w500,
              ),
            ),
          ),

          if (_searchController
              .text
              .isNotEmpty)
            IconButton(
              onPressed: () {
                _searchController.clear();

                setState(() {});
              },

              icon: Icon(
                Icons.close_rounded,
                size: 19,
                color:
                    Colors.grey.shade500,
              ),
            ),

          IconButton(
            onPressed:
                _showFilterSheet,

            icon: Icon(
              Icons.tune_rounded,
              size: 21,
              color:
                  Colors.grey.shade600,
            ),
          ),

          const SizedBox(width: 3),
        ],
      ),
    );
  }

  // ============================================================
  // QUICK STATS
  // ============================================================

  Widget _buildQuickStats(
    DashboardStats stats,
  ) {
    return Row(
      children: [
        Expanded(
          child: _StatCard(
            icon:
                Icons.shopping_bag_outlined,
            label: 'Orders',
            value:
                stats.totalOrders.toString(),
          ),
        ),

        const SizedBox(width: 10),

        Expanded(
          child: _StatCard(
            icon:
                Icons.favorite_border_rounded,
            label: 'Wishlist',
            value:
                stats.wishlistCount
                    .toString(),
          ),
        ),

        const SizedBox(width: 10),

        Expanded(
          child: _StatCard(
            icon:
                Icons.shopping_cart_outlined,
            label: 'Cart',
            value:
                stats.cartCount.toString(),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // BANNER
  // ============================================================

  Widget _buildBanner() {
    return Container(
      width: double.infinity,

      height: 178,

      padding:
          const EdgeInsets.fromLTRB(
        22,
        20,
        20,
        20,
      ),

      decoration:
          BoxDecoration(
        color: primaryBlue,

        borderRadius:
            BorderRadius.circular(21),

        boxShadow: [
          BoxShadow(
            color:
                primaryBlue.withOpacity(
              0.16,
            ),

            blurRadius: 18,

            offset:
                const Offset(0, 8),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          const Text(
            'KWARIHUB MARKETPLACE',
            style: TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight:
                  FontWeight.w800,
              letterSpacing: 1.3,
            ),
          ),

          const SizedBox(height: 10),

          const Text(
            'Discover quality\ntextiles & fabrics',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              height: 1.18,
              fontWeight:
                  FontWeight.w900,
            ),
          ),

          const Spacer(),

          GestureDetector(
            onTap: _openCategories,

            child: const Row(
              mainAxisSize:
                  MainAxisSize.min,

              children: [
                Text(
                  'Shop Now',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),

                SizedBox(width: 7),

                Icon(
                  Icons
                      .arrow_forward_rounded,
                  color: Colors.white,
                  size: 17,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CATEGORIES
  // ============================================================

  Widget _buildCategories(
    List<DashboardCategory>
        categories,
  ) {
    if (categories.isEmpty) {
      return const Padding(
        padding:
            EdgeInsets.fromLTRB(
          24,
          14,
          24,
          0,
        ),

        child: _EmptySection(
          message:
              'No featured categories available.',
        ),
      );
    }

    return SizedBox(
      height: 112,

      child: ListView.separated(
        padding:
            const EdgeInsets.fromLTRB(
          24,
          14,
          24,
          0,
        ),

        scrollDirection:
            Axis.horizontal,

        physics:
            const BouncingScrollPhysics(),

        itemCount:
            categories.length,

        separatorBuilder:
            (_, __) {
          return const SizedBox(
            width: 15,
          );
        },

        itemBuilder:
            (context, index) {
          final category =
              categories[index];

          return _CategoryCard(
            category: category,

            onTap: () {
              _openCategory(
                category,
              );
            },
          );
        },
      ),
    );
  }

  // ============================================================
  // CATEGORY
  // ============================================================

  void _openCategory(
    DashboardCategory category,
  ) {
    context.push(
      '/categories/${category.uuid}',
    );
  }

  // ============================================================
  // PRODUCT
  // ============================================================

  void _openProduct(
    DashboardProduct product,
  ) {
    context.push(
      '/products/${product.uuid}',
    );
  }

  // ============================================================
  // FILTER
  // ============================================================

  void _showFilterSheet() {
    showModalBottomSheet(
      context: context,

      backgroundColor:
          Colors.white,

      shape:
          const RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(
          top: Radius.circular(24),
        ),
      ),

      builder: (context) {
        return SafeArea(
          child: Padding(
            padding:
                const EdgeInsets.all(24),

            child: Column(
              mainAxisSize:
                  MainAxisSize.min,

              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                const Text(
                  'Filter Products',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight:
                        FontWeight.w800,
                    color: darkBlue,
                  ),
                ),

                const SizedBox(
                  height: 20,
                ),

                const _FilterOption(
                  title: 'Newest',
                ),

                const _FilterOption(
                  title: 'Popular',
                ),

                const _FilterOption(
                  title:
                      'Price: Low to High',
                ),

                const _FilterOption(
                  title:
                      'Price: High to Low',
                ),

                const SizedBox(
                  height: 15,
                ),

                SizedBox(
                  width:
                      double.infinity,

                  height: 52,

                  child:
                      ElevatedButton(
                    onPressed: () {
                      Navigator.pop(
                        context,
                      );
                    },

                    style:
                        ElevatedButton
                            .styleFrom(
                      backgroundColor:
                          primaryBlue,

                      elevation: 0,

                      shape:
                          RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius
                                .circular(
                          14,
                        ),
                      ),
                    ),

                    child:
                        const Text(
                      'Apply Filter',
                      style:
                          TextStyle(
                        color:
                            Colors.white,
                        fontWeight:
                            FontWeight
                                .w800,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // BOTTOM NAVIGATION
  // ============================================================

  Widget _buildBottomNavigation() {
    return Container(
      decoration:
          BoxDecoration(
        color: Colors.white,

        border: Border(
          top: BorderSide(
            color:
                borderColor.withOpacity(
              0.7,
            ),
          ),
        ),
      ),

      child: SafeArea(
        top: false,

        child: Padding(
          padding:
              const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 7,
          ),

          child: Row(
            mainAxisAlignment:
                MainAxisAlignment
                    .spaceAround,

            children: [
              _BottomNavItem(
                icon:
                    Icons.home_rounded,
                label: 'Home',
                selected: true,
                onTap: () {},
              ),

              _BottomNavItem(
                icon:
                    Icons.grid_view_rounded,
                label: 'Categories',
                selected: false,
                onTap:
                    _openCategories,
              ),

              _BottomNavItem(
                icon:
                    Icons.shopping_bag_outlined,
                label: 'Cart',
                selected: false,
                onTap:
                    _openCart,
              ),

              _BottomNavItem(
                icon:
                    Icons.favorite_border_rounded,
                label: 'Wishlist',
                selected: false,
                onTap:
                    _openWishlist,
              ),

              _BottomNavItem(
                icon:
                    Icons.person_outline_rounded,
                label: 'Profile',
                selected: false,
                onTap:
                    _openProfile,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================================================================
// CATEGORY CARD
// ================================================================

class _CategoryCard
    extends StatelessWidget {
  const _CategoryCard({
    required this.category,
    required this.onTap,
  });

  final DashboardCategory category;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: onTap,

      child: SizedBox(
        width: 72,

        child: Column(
          children: [
            Container(
              width: 62,
              height: 62,

              decoration:
                  BoxDecoration(
                color:
                    const Color(
                  0xFFFAFCFF,
                ),

                borderRadius:
                    BorderRadius
                        .circular(
                  17,
                ),

                border:
                    Border.all(
                  color:
                      const Color(
                    0xFFF0F4F8,
                  ),
                ),
              ),

              child:
                  _CategoryIcon(
                icon:
                    category.icon,
              ),
            ),

            const SizedBox(
              height: 7,
            ),

            Text(
              category.name,

              maxLines: 1,

              overflow:
                  TextOverflow.ellipsis,

              textAlign:
                  TextAlign.center,

              style: TextStyle(
                fontSize: 11,
                color:
                    Colors.grey.shade700,
                fontWeight:
                    FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// CATEGORY ICON
// ================================================================

class _CategoryIcon
    extends StatelessWidget {
  const _CategoryIcon({
    required this.icon,
  });

  final String? icon;

  @override
  Widget build(
    BuildContext context,
  ) {
    if (icon == null ||
        icon!.trim().isEmpty) {
      return const Icon(
        Icons.checkroom_outlined,
        size: 25,
        color: Color(0xFF0D5CC7),
      );
    }

    if (icon!.startsWith('http')) {
      return ClipRRect(
        borderRadius:
            BorderRadius.circular(
          17,
        ),

        child: Image.network(
          icon!,

          fit: BoxFit.cover,

          errorBuilder:
              (_, __, ___) {
            return const Icon(
              Icons.checkroom_outlined,
              size: 25,
              color:
                  Color(0xFF0D5CC7),
            );
          },
        ),
      );
    }

    return const Icon(
      Icons.checkroom_outlined,
      size: 25,
      color: Color(0xFF0D5CC7),
    );
  }
}

// ================================================================
// PRODUCT CARD
// ================================================================

class _ProductCard
    extends StatefulWidget {
  const _ProductCard({
    required this.product,
    required this.onTap,
  });

  final DashboardProduct product;
  final VoidCallback onTap;

  @override
  State<_ProductCard> createState() =>
      _ProductCardState();
}

class _ProductCardState
    extends State<_ProductCard> {
  bool _isFavorite = false;

  @override
  Widget build(
    BuildContext context,
  ) {
    final product =
        widget.product;

    return GestureDetector(
      onTap: widget.onTap,

      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Expanded(
            child: Stack(
              children: [
                Container(
                  width:
                      double.infinity,

                  decoration:
                      BoxDecoration(
                    color:
                        const Color(
                      0xFFF5F8FC,
                    ),

                    borderRadius:
                        BorderRadius
                            .circular(
                      17,
                    ),
                  ),

                  child:
                      _ProductImage(
                    image:
                        product.image,
                  ),
                ),

                // ------------------------------------------------
                // FAVORITE
                // ------------------------------------------------

                Positioned(
                  top: 9,
                  right: 9,

                  child: Material(
                    color:
                        Colors.white,

                    shape:
                        const CircleBorder(),

                    child: InkWell(
                      customBorder:
                          const CircleBorder(),

                      onTap: () {
                        setState(() {
                          _isFavorite =
                              !_isFavorite;
                        });
                      },

                      child:
                          Padding(
                        padding:
                            const EdgeInsets
                                .all(
                          7,
                        ),

                        child:
                            Icon(
                          _isFavorite
                              ? Icons
                                  .favorite_rounded
                              : Icons
                                  .favorite_border_rounded,

                          size: 18,

                          color:
                              _isFavorite
                                  ? Colors.red
                                  : Colors
                                      .grey
                                      .shade600,
                        ),
                      ),
                    ),
                  ),
                ),

                // ------------------------------------------------
                // SALE
                // ------------------------------------------------

                if (product.hasDiscount)
                  Positioned(
                    top: 9,
                    left: 9,

                    child:
                        Container(
                      padding:
                          const EdgeInsets
                              .symmetric(
                        horizontal:
                            8,
                        vertical: 5,
                      ),

                      decoration:
                          BoxDecoration(
                        color:
                            Colors.red
                                .shade600,

                        borderRadius:
                            BorderRadius
                                .circular(
                          8,
                        ),
                      ),

                      child:
                          const Text(
                        'SALE',
                        style:
                            TextStyle(
                          color:
                              Colors.white,
                          fontSize:
                              9,
                          fontWeight:
                              FontWeight
                                  .w800,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),

          const SizedBox(
            height: 9,
          ),

          // ------------------------------------------------------
          // NAME
          // ------------------------------------------------------

          Text(
            product.name,

            maxLines: 1,

            overflow:
                TextOverflow.ellipsis,

            style:
                const TextStyle(
              fontSize: 13,
              fontWeight:
                  FontWeight.w700,
              color: Color(
                0xFF102F4F,
              ),
            ),
          ),

          const SizedBox(
            height: 4,
          ),

          // ------------------------------------------------------
          // BRAND / UNIT
          // ------------------------------------------------------

          Text(
            product.brand ??
                product.unit,

            maxLines: 1,

            overflow:
                TextOverflow.ellipsis,

            style: TextStyle(
              fontSize: 11,
              color:
                  Colors.grey.shade500,
            ),
          ),

          const SizedBox(
            height: 5,
          ),

          // ------------------------------------------------------
          // PRICE
          // ------------------------------------------------------

          Row(
            crossAxisAlignment:
                CrossAxisAlignment.end,

            children: [
              Text(
                _formatPrice(
                  product
                      .discountPriceValue ??
                      product.priceValue,
                ),

                style:
                    const TextStyle(
                  fontSize: 14,
                  fontWeight:
                      FontWeight.w900,
                  color:
                      Color(
                    0xFF0D5CC7,
                  ),
                ),
              ),

              if (product.hasDiscount)
                Padding(
                  padding:
                      const EdgeInsets
                          .only(
                    left: 6,
                    bottom: 1,
                  ),

                  child: Text(
                    _formatPrice(
                      product.priceValue,
                    ),

                    style:
                        TextStyle(
                      fontSize: 10,
                      color:
                          Colors
                              .grey
                              .shade500,

                      decoration:
                          TextDecoration
                              .lineThrough,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatPrice(
    double value,
  ) {
    return NumberFormat.currency(
      locale: 'en_NG',
      symbol: '₦',
      decimalDigits: 0,
    ).format(value);
  }
}

// ================================================================
// PRODUCT IMAGE
// ================================================================

class _ProductImage
    extends StatelessWidget {
  const _ProductImage({
    required this.image,
  });

  final String? image;

  @override
  Widget build(
    BuildContext context,
  ) {
    if (image == null ||
        image!.trim().isEmpty) {
      return const Center(
        child: Icon(
          Icons.image_outlined,
          color:
              Color(0xFF0D5CC7),
          size: 38,
        ),
      );
    }

    return ClipRRect(
      borderRadius:
          BorderRadius.circular(
        17,
      ),

      child: Image.network(
        image!,

        width: double.infinity,
        height: double.infinity,

        fit: BoxFit.cover,

        errorBuilder:
            (_, __, ___) {
          return const Center(
            child: Icon(
              Icons.broken_image_outlined,
              color:
                  Color(0xFF0D5CC7),
              size: 38,
            ),
          );
        },
      ),
    );
  }
}

// ================================================================
// STAT CARD
// ================================================================

class _StatCard
    extends StatelessWidget {
  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.all(
        13,
      ),

      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFFAFCFF,
        ),

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              const Color(
            0xFFEAF0F6,
          ),
        ),
      ),

      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Icon(
            icon,
            size: 20,
            color:
                const Color(
              0xFF0D5CC7,
            ),
          ),

          const SizedBox(
            height: 8,
          ),

          Text(
            value,

            style:
                const TextStyle(
              fontSize: 17,
              fontWeight:
                  FontWeight.w900,
              color:
                  Color(
                0xFF102F4F,
              ),
            ),
          ),

          const SizedBox(
            height: 2,
          ),

          Text(
            label,

            style:
                TextStyle(
              fontSize: 10,
              color:
                  Colors.grey.shade600,
              fontWeight:
                  FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// HEADER BUTTON
// ================================================================

class _HeaderIconButton
    extends StatelessWidget {
  const _HeaderIconButton({
    required this.icon,
    required this.onPressed,
    this.badge = 0,
  });

  final IconData icon;
  final VoidCallback onPressed;
  final int badge;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Stack(
      clipBehavior:
          Clip.none,

      children: [
        IconButton(
          onPressed:
              onPressed,

          style:
              IconButton.styleFrom(
            foregroundColor:
                const Color(
              0xFF102F4F,
            ),

            fixedSize:
                const Size(
              44,
              44,
            ),
          ),

          icon: Icon(
            icon,
            size: 25,
          ),
        ),

        if (badge > 0)
          Positioned(
            right: 5,
            top: 3,

            child:
                Container(
              constraints:
                  const BoxConstraints(
                minWidth: 17,
                minHeight: 17,
              ),

              padding:
                  const EdgeInsets
                      .symmetric(
                horizontal: 4,
              ),

              decoration:
                  BoxDecoration(
                color:
                    Colors.red.shade600,

                shape:
                    BoxShape.circle,

                border:
                    Border.all(
                  color:
                      Colors.white,
                  width: 1.5,
                ),
              ),

              child:
                  Center(
                child:
                    Text(
                  badge > 99
                      ? '99+'
                      : badge
                          .toString(),

                  style:
                      const TextStyle(
                    color:
                        Colors.white,
                    fontSize:
                        8,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

// ================================================================
// SECTION HEADER
// ================================================================

class _SectionHeader
    extends StatelessWidget {
  const _SectionHeader({
    required this.title,
    required this.action,
    required this.onTap,
  });

  final String title;
  final String action;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,

            style:
                const TextStyle(
              fontSize: 21,
              fontWeight:
                  FontWeight.w900,
              color:
                  Color(
                0xFF102F4F,
              ),
            ),
          ),
        ),

        GestureDetector(
          onTap: onTap,

          child:
              const Text(
            'See All',

            style:
                TextStyle(
              color:
                  Color(
                0xFF0D5CC7,
              ),

              fontSize:
                  13,

              fontWeight:
                  FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

// ================================================================
// FILTER OPTION
// ================================================================

class _FilterOption
    extends StatelessWidget {
  const _FilterOption({
    required this.title,
  });

  final String title;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        bottom: 13,
      ),

      child: Row(
        children: [
          const Icon(
            Icons
                .radio_button_unchecked,

            color:
                Color(
              0xFF0D5CC7,
            ),

            size: 21,
          ),

          const SizedBox(
            width: 12,
          ),

          Text(
            title,

            style:
                const TextStyle(
              fontSize: 14,
              color:
                  Color(
                0xFF102F4F,
              ),
              fontWeight:
                  FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// RECENT ORDERS
// ================================================================

class _RecentOrders
    extends StatelessWidget {
  const _RecentOrders({
    required this.orders,
  });

  final List<RecentOrder> orders;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,

      children: [
        _SectionHeader(
          title: 'Recent Orders',
          action: 'See All',
          onTap: () {
            context.push('/orders');
          },
        ),

        const SizedBox(
          height: 14,
        ),

        ...orders.take(3).map(
          (order) {
            return Container(
              margin:
                  const EdgeInsets.only(
                bottom: 10,
              ),

              padding:
                  const EdgeInsets.all(
                14,
              ),

              decoration:
                  BoxDecoration(
                color:
                    const Color(
                  0xFFFAFCFF,
                ),

                borderRadius:
                    BorderRadius.circular(
                  14,
                ),

                border:
                    Border.all(
                  color:
                      const Color(
                    0xFFEAF0F6,
                  ),
                ),
              ),

              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,

                    decoration:
                        BoxDecoration(
                      color:
                          const Color(
                        0xFFF4F8FF,
                      ),

                      borderRadius:
                          BorderRadius
                              .circular(
                        12,
                      ),
                    ),

                    child:
                        const Icon(
                      Icons
                          .shopping_bag_outlined,

                      color:
                          Color(
                        0xFF0D5CC7,
                      ),

                      size: 21,
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child:
                        Column(
                      crossAxisAlignment:
                          CrossAxisAlignment
                              .start,

                      children: [
                        Text(
                          order
                              .orderNumber,

                          style:
                              const TextStyle(
                            fontSize:
                                13,
                            fontWeight:
                                FontWeight
                                    .w800,
                            color:
                                Color(
                              0xFF102F4F,
                            ),
                          ),
                        ),

                        const SizedBox(
                          height: 3,
                        ),

                        Text(
                          order.status,

                          style:
                              TextStyle(
                            fontSize:
                                11,
                            color:
                                Colors
                                    .grey
                                    .shade600,
                          ),
                        ),
                      ],
                    ),
                  ),

                  Text(
                    NumberFormat.currency(
                      locale:
                          'en_NG',
                      symbol:
                          '₦',
                      decimalDigits:
                          0,
                    ).format(
                      order.totalValue,
                    ),

                    style:
                        const TextStyle(
                      fontSize:
                          13,
                      fontWeight:
                          FontWeight
                              .w900,
                      color:
                          Color(
                        0xFF0D5CC7,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}

// ================================================================
// EMPTY SECTION
// ================================================================

class _EmptySection
    extends StatelessWidget {
  const _EmptySection({
    required this.message,
  });

  final String message;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      width: double.infinity,

      margin:
          const EdgeInsets.only(
        top: 4,
      ),

      padding:
          const EdgeInsets.all(
        18,
      ),

      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFFAFCFF,
        ),

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              const Color(
            0xFFEAF0F6,
          ),
        ),
      ),

      child: Center(
        child: Text(
          message,

          textAlign:
              TextAlign.center,

          style:
              TextStyle(
            color:
                Colors.grey.shade600,

            fontSize:
                12,
          ),
        ),
      ),
    );
  }
}

// ================================================================
// BOTTOM NAV ITEM
// ================================================================

class _BottomNavItem
    extends StatelessWidget {
  const _BottomNavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: onTap,

      behavior:
          HitTestBehavior.opaque,

      child: SizedBox(
        width: 65,

        child: Column(
          mainAxisSize:
              MainAxisSize.min,

          children: [
            Icon(
              icon,
              size: 24,

              color: selected
                  ? const Color(
                      0xFF0D5CC7,
                    )
                  : Colors.grey.shade400,
            ),

            const SizedBox(
              height: 4,
            ),

            Text(
              label,

              maxLines: 1,

              overflow:
                  TextOverflow.ellipsis,

              style: TextStyle(
                fontSize: 11,

                fontWeight:
                    selected
                        ? FontWeight.w700
                        : FontWeight.w500,

                color: selected
                    ? const Color(
                        0xFF0D5CC7,
                      )
                    : Colors.grey.shade400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// LOADING
// ================================================================

class _DashboardLoading
    extends StatelessWidget {
  const _DashboardLoading();

  @override
  Widget build(
    BuildContext context,
  ) {
    return const Center(
      child:
          CircularProgressIndicator(
        color:
            Color(0xFF0D5CC7),
      ),
    );
  }
}

// ================================================================
// ERROR
// ================================================================

class _DashboardError
    extends StatelessWidget {
  const _DashboardError({
    required this.message,
    required this.onRetry,
  });

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Center(
      child: Padding(
        padding:
            const EdgeInsets.all(
          24,
        ),

        child: Column(
          mainAxisAlignment:
              MainAxisAlignment
                  .center,

          children: [
            Container(
              width: 72,
              height: 72,

              decoration:
                  BoxDecoration(
                color:
                    const Color(
                  0xFFF4F8FF,
                ),

                borderRadius:
                    BorderRadius.circular(
                  20,
                ),
              ),

              child:
                  const Icon(
                Icons
                    .cloud_off_rounded,

                color:
                    Color(
                  0xFF0D5CC7,
                ),

                size: 34,
              ),
            ),

            const SizedBox(
              height: 18,
            ),

            const Text(
              'Unable to load dashboard',

              textAlign:
                  TextAlign.center,

              style:
                  TextStyle(
                fontSize: 19,
                fontWeight:
                    FontWeight.w800,
                color:
                    Color(
                  0xFF102F4F,
                ),
              ),
            ),

            const SizedBox(
              height: 8,
            ),

            Text(
              message,

              textAlign:
                  TextAlign.center,

              style:
                  TextStyle(
                fontSize: 13,
                color:
                    Colors.grey.shade600,
              ),
            ),

            const SizedBox(
              height: 20,
            ),

            SizedBox(
              height: 48,

              child:
                  ElevatedButton(
                onPressed:
                    onRetry,

                style:
                    ElevatedButton
                        .styleFrom(
                  backgroundColor:
                      const Color(
                    0xFF0D5CC7,
                  ),

                  elevation: 0,

                  shape:
                      RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(
                      13,
                    ),
                  ),
                ),

                child:
                    const Text(
                  'Try Again',

                  style:
                      TextStyle(
                    color:
                        Colors.white,

                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}