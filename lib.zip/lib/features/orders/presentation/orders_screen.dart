import 'package:flutter/material.dart';
class OrdersScreen extends StatelessWidget { const OrdersScreen({super.key}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Orders')),body:Center(child:Text('Orders',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w800)))); }
