import 'package:dio/dio.dart';

import '../../../core/network/api_client.dart';
import '../models/product_image_model.dart';
import '../models/product_model.dart';
import '../models/product_variant_model.dart';

class ProductApi {
  ProductApi({
    Dio? dio,
  }) : _dio = dio ?? ApiClient.instance.dio;

  final Dio _dio;

  // ============================================================
  // PRODUCT
  // ============================================================

  Future<ProductModel> getProduct(
    String uuid,
  ) async {
    try {
      final response = await _dio.get(
        '/products/$uuid',
      );

      final data = response.data;

      if (data is! Map<String, dynamic>) {
        throw Exception(
          'Invalid product response.',
        );
      }

      return ProductModel.fromJson(data);
    } on DioException catch (e) {
      throw Exception(
        _handleError(
          e,
          fallback:
              'Unable to load product.',
        ),
      );
    }
  }

  // ============================================================
  // PRODUCT IMAGES
  // ============================================================

  Future<List<ProductImageModel>> getProductImages(
    String uuid,
  ) async {
    try {
      final response = await _dio.get(
        '/products/$uuid/images',
      );

      final data = response.data;

      if (data is! List) {
        throw Exception(
          'Invalid product images response.',
        );
      }

      return data
          .whereType<Map<String, dynamic>>()
          .map(
            ProductImageModel.fromJson,
          )
          .toList();
    } on DioException catch (e) {
      throw Exception(
        _handleError(
          e,
          fallback:
              'Unable to load product images.',
        ),
      );
    }
  }

  // ============================================================
  // PRODUCT VARIANTS
  // ============================================================

  Future<List<ProductVariantModel>> getProductVariants(
    String uuid,
  ) async {
    try {
      final response = await _dio.get(
        '/products/$uuid/variants',
      );

      final data = response.data;

      if (data is! List) {
        throw Exception(
          'Invalid product variants response.',
        );
      }

      return data
          .whereType<Map<String, dynamic>>()
          .map(
            ProductVariantModel.fromJson,
          )
          .toList();
    } on DioException catch (e) {
      throw Exception(
        _handleError(
          e,
          fallback:
              'Unable to load product variants.',
        ),
      );
    }
  }

  // ============================================================
  // ERROR
  // ============================================================

  String _handleError(
    DioException error, {
    required String fallback,
  }) {
    if (error.response != null) {
      final data = error.response?.data;

      if (data is Map<String, dynamic>) {
        final detail = data['detail'];

        if (detail is String) {
          return detail;
        }

        if (detail is List &&
            detail.isNotEmpty) {
          return detail.first.toString();
        }

        final message = data['message'];

        if (message is String) {
          return message;
        }
      }

      return '$fallback '
          'Status: ${error.response?.statusCode}';
    }

    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
      case DioExceptionType.sendTimeout:
        return 'Connection timed out. Please try again.';

      case DioExceptionType.connectionError:
        return 'Unable to connect to KwariHub server.';

      default:
        return fallback;
    }
  }
}