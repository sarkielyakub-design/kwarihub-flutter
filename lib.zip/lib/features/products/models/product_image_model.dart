class ProductImageModel {
  final int id;
  final String uuid;
  final int productId;
  final String image;
  final bool isPrimary;
  final int sortOrder;

  const ProductImageModel({
    required this.id,
    required this.uuid,
    required this.productId,
    required this.image,
    required this.isPrimary,
    required this.sortOrder,
  });

  factory ProductImageModel.fromJson(
    Map<String, dynamic> json,
  ) {
    return ProductImageModel(
      id: _toInt(json['id']),
      uuid: json['uuid']?.toString() ?? '',
      productId: _toInt(json['product_id']),
      image: json['image']?.toString() ?? '',
      isPrimary: json['is_primary'] == true,
      sortOrder: _toInt(json['sort_order']),
    );
  }

  static int _toInt(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value.toString()) ?? 0;
  }
}