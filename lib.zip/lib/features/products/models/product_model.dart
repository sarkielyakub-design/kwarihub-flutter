class ProductModel {
  final int id;
  final String uuid;
  final int sellerId;
  final int categoryId;
  final String name;
  final String slug;
  final String sku;
  final String description;
  final double price;
  final double? discountPrice;
  final int quantity;
  final String unit;
  final String? brand;
  final String? origin;
  final String status;
  final bool isFeatured;
  final bool isActive;

  const ProductModel({
    required this.id,
    required this.uuid,
    required this.sellerId,
    required this.categoryId,
    required this.name,
    required this.slug,
    required this.sku,
    required this.description,
    required this.price,
    required this.discountPrice,
    required this.quantity,
    required this.unit,
    required this.brand,
    required this.origin,
    required this.status,
    required this.isFeatured,
    required this.isActive,
  });

  factory ProductModel.fromJson(
    Map<String, dynamic> json,
  ) {
    return ProductModel(
      id: _toInt(json['id']),
      uuid: json['uuid']?.toString() ?? '',
      sellerId: _toInt(json['seller_id']),
      categoryId: _toInt(json['category_id']),
      name: json['name']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      sku: json['sku']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      price: _toDouble(json['price']),
      discountPrice: json['discount_price'] == null
          ? null
          : _toDouble(json['discount_price']),
      quantity: _toInt(json['quantity']),
      unit: json['unit']?.toString() ?? '',
      brand: json['brand']?.toString(),
      origin: json['origin']?.toString(),
      status: json['status']?.toString() ?? '',
      isFeatured: json['is_featured'] == true,
      isActive: json['is_active'] != false,
    );
  }

  bool get hasDiscount {
    return discountPrice != null &&
        discountPrice! > 0 &&
        discountPrice! < price;
  }

  double get sellingPrice {
    if (hasDiscount) {
      return discountPrice!;
    }

    return price;
  }

  static int _toInt(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value.toString()) ?? 0;
  }

  static double _toDouble(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value.toString()) ?? 0;
  }
}