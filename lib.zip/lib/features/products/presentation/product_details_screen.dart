import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:kwarihub/core/config/app_config.dart';
import 'package:kwarihub/core/network/api_client.dart';
import 'package:kwarihub/features/wishlist/providers/wishlist_provider.dart';

import '../models/product_image_model.dart';
import '../models/product_variant_model.dart';
import '../providers/product_details_provider.dart';

// ================================================================
// KWARIHUB PRODUCT DETAILS COLORS
// ================================================================

const Color primaryBlue = Color(0xFF0D5CC7);
const Color darkBlue = Color(0xFF102F4F);
const Color lightBlue = Color(0xFFF4F8FF);
const Color borderColor = Color(0xFFE2EAF3);

class ProductDetailsScreen extends ConsumerStatefulWidget {
  const ProductDetailsScreen({
    super.key,
    required this.productId,
  });

  final String productId;

  @override
  ConsumerState<ProductDetailsScreen> createState() =>
      _ProductDetailsScreenState();
}

class _ProductDetailsScreenState
    extends ConsumerState<ProductDetailsScreen> {

  // ================================================================
  // STATE
  // ================================================================

  int _selectedImage = 0;
  int _quantity = 1;

  String? _selectedVariant;

  bool _addingToCart = false;
  bool _wishlistUpdating = false;

  // ... keep the rest of the code exactly as I gave you

  // ================================================================
  // REFRESH
  // ================================================================

  Future<void> _refresh() async {
    ref.invalidate(
      productDetailsProvider(widget.productId),
    );

    await ref.read(
      productDetailsProvider(widget.productId).future,
    );

    // Also refresh wishlist state.
    ref.invalidate(wishlistProvider);
  }

  // ================================================================
  // QUANTITY
  // ================================================================

  void _increaseQuantity(int available) {
    if (available <= 0) {
      return;
    }

    if (_quantity < available) {
      setState(() {
        _quantity++;
      });
    }
  }

  void _decreaseQuantity() {
    if (_quantity > 1) {
      setState(() {
        _quantity--;
      });
    }
  }

  // ================================================================
  // ADD TO CART
  // ================================================================

  Future<void> _addToCart({
    required String? variantUuid,
    required int availableQuantity,
  }) async {
    if (_addingToCart) {
      return;
    }

    if (availableQuantity <= 0) {
      _showMessage(
        'This product is currently out of stock.',
      );
      return;
    }

    if (variantUuid == null || variantUuid.trim().isEmpty) {
      _showMessage(
        'Please select a product variant first.',
      );
      return;
    }

    final quantity = _quantity.clamp(
      1,
      availableQuantity,
    );

    setState(() {
      _addingToCart = true;
    });

    try {
      final response = await ApiClient.instance.dio.post(
        '/cart',
        data: {
          'variant_uuid': variantUuid.trim(),
          'quantity': quantity,
        },
      );

      if (!mounted) {
        return;
      }

      if (response.statusCode == 200 ||
          response.statusCode == 201) {
        _showMessage(
          'Product added to cart successfully.',
          success: true,
        );

        await Future.delayed(
          const Duration(milliseconds: 500),
        );

        if (!mounted) {
          return;
        }

        context.push('/cart');
        return;
      }

      _showMessage(
        'Unable to add product to cart.',
      );
    } on DioException catch (error) {
      if (!mounted) {
        return;
      }

      if (error.response?.statusCode == 401) {
        _showMessage(
          'Please login to add products to your cart.',
        );

        await Future.delayed(
          const Duration(milliseconds: 700),
        );

        if (!mounted) {
          return;
        }

        context.push('/login');
        return;
      }

      _showMessage(
        _extractApiError(error),
      );
    } catch (_) {
      if (!mounted) {
        return;
      }

      _showMessage(
        'Unable to add product to cart.',
      );
    } finally {
      if (mounted) {
        setState(() {
          _addingToCart = false;
        });
      }
    }
  }

  // ================================================================
  // WISHLIST
  // ================================================================

  Future<void> _toggleFavorite(
    String productUuid,
  ) async {
    if (_wishlistUpdating) {
      return;
    }

    final uuid = productUuid.trim();

    if (uuid.isEmpty) {
      _showMessage(
        'Unable to update wishlist.',
      );
      return;
    }

    final wishlistNotifier =
        ref.read(wishlistProvider.notifier);

    final currentlyInWishlist =
        wishlistNotifier.contains(uuid);

    setState(() {
      _wishlistUpdating = true;
    });

    try {
      final bool success;

      if (currentlyInWishlist) {
        success = await wishlistNotifier.remove(uuid);
      } else {
        success = await wishlistNotifier.add(uuid);
      }

      if (!mounted) {
        return;
      }

      if (success) {
        _showMessage(
          currentlyInWishlist
              ? 'Removed from wishlist.'
              : 'Added to wishlist.',
          success: true,
        );
      } else {
        _showMessage(
          'Unable to update wishlist.',
        );
      }
    } on DioException catch (error) {
      if (!mounted) {
        return;
      }

      if (error.response?.statusCode == 401) {
        _showMessage(
          'Please login to manage your wishlist.',
        );

        await Future.delayed(
          const Duration(milliseconds: 700),
        );

        if (!mounted) {
          return;
        }

        context.push('/login');
        return;
      }

      _showMessage(
        _extractWishlistApiError(error),
      );
    } catch (_) {
      if (!mounted) {
        return;
      }

      _showMessage(
        'Unable to update wishlist.',
      );
    } finally {
      if (mounted) {
        setState(() {
          _wishlistUpdating = false;
        });
      }
    }
  }

  // ================================================================
  // API ERROR
  // ================================================================

  String _extractApiError(
    DioException error,
  ) {
    final data = error.response?.data;

    if (data is Map<String, dynamic>) {
      final detail = data['detail'];

      if (detail is String &&
          detail.trim().isNotEmpty) {
        return detail;
      }

      final message = data['message'];

      if (message is String &&
          message.trim().isNotEmpty) {
        return message;
      }

      final errorMessage = data['error'];

      if (errorMessage is String &&
          errorMessage.trim().isNotEmpty) {
        return errorMessage;
      }
    }

    if (error.response?.statusCode == 401) {
      return 'Please login to continue.';
    }

    if (error.response?.statusCode == 400) {
      return 'Unable to add this product. Please check the quantity and variant.';
    }

    if (error.response?.statusCode == 404) {
      return 'Product variant not found.';
    }

    if (error.response?.statusCode == 500) {
      return 'Server error. Please try again.';
    }

    if (error.type ==
        DioExceptionType.connectionError) {
      return 'Unable to connect to KwariHub server.';
    }

    return 'Unable to add product to cart.';
  }

  String _extractWishlistApiError(
    DioException error,
  ) {
    final data = error.response?.data;

    if (data is Map<String, dynamic>) {
      final detail = data['detail'];

      if (detail is String &&
          detail.trim().isNotEmpty) {
        return detail;
      }

      final message = data['message'];

      if (message is String &&
          message.trim().isNotEmpty) {
        return message;
      }

      final errorMessage = data['error'];

      if (errorMessage is String &&
          errorMessage.trim().isNotEmpty) {
        return errorMessage;
      }
    }

    if (error.response?.statusCode == 401) {
      return 'Please login to continue.';
    }

    if (error.response?.statusCode == 404) {
      return 'Product is not available.';
    }

    if (error.response?.statusCode == 400) {
      return 'Unable to update wishlist.';
    }

    if (error.type ==
        DioExceptionType.connectionError) {
      return 'Unable to connect to KwariHub server.';
    }

    return 'Unable to update wishlist.';
  }

  // ================================================================
  // MESSAGE
  // ================================================================

  void _showMessage(
    String message, {
    bool success = false,
  }) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context)
        .hideCurrentSnackBar();

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        behavior:
            SnackBarBehavior.floating,
        backgroundColor:
            success
                ? Colors.green.shade700
                : darkBlue,
        duration:
            const Duration(seconds: 2),
        shape:
            RoundedRectangleBorder(
          borderRadius:
              BorderRadius.circular(12),
        ),
        content:
            Text(
          message,
          style:
              const TextStyle(
            color:
                Colors.white,
            fontWeight:
                FontWeight.w600,
          ),
        ),
      ),
    );
  }

  // ================================================================
  // BUILD
  // ================================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    final productAsync =
        ref.watch(
      productDetailsProvider(
        widget.productId,
      ),
    );

    return Scaffold(
      backgroundColor:
          Colors.white,
      body:
          SafeArea(
        child:
            productAsync.when(
          // ==========================================================
          // LOADING
          // ==========================================================

          loading: () {
            return const _ProductLoading();
          },

          // ==========================================================
          // ERROR
          // ==========================================================

          error: (
            error,
            stackTrace,
          ) {
            return _ProductError(
              message:
                  error
                      .toString()
                      .replaceFirst(
                        'Exception: ',
                        '',
                      ),
              onRetry:
                  _refresh,
            );
          },

          // ==========================================================
          // DATA
          // ==========================================================

          data: (
            data,
          ) {
            final product =
                data.product;

            final images =
                data.images;

            final variants =
                data.variants;

            // --------------------------------------------------------
            // WISHLIST STATE
            // --------------------------------------------------------

            final wishlistState =
                ref.watch(
              wishlistProvider,
            );

            final isInWishlist =
                wishlistState.asData?.value.any(
                      (item) =>
                          item.product.uuid ==
                          product.uuid,
                    ) ??
                    false;

            // --------------------------------------------------------
            // SAFE IMAGE INDEX
            // --------------------------------------------------------

            final safeSelectedImage =
                images.isEmpty
                    ? 0
                    : _selectedImage.clamp(
                        0,
                        images.length - 1,
                      );

            // --------------------------------------------------------
            // SELECTED VARIANT
            // --------------------------------------------------------

            ProductVariantModel?
                selectedVariant;

            if (_selectedVariant != null) {
              for (final variant
                  in variants) {
                if (variant.uuid ==
                    _selectedVariant) {
                  selectedVariant =
                      variant;
                  break;
                }
              }
            }

            // --------------------------------------------------------
            // STOCK
            // --------------------------------------------------------

            final effectiveAvailableQuantity =
                selectedVariant != null
                    ? selectedVariant.quantity
                    : product.quantity;

            // --------------------------------------------------------
            // SAFE QUANTITY
            // --------------------------------------------------------

            final effectiveQuantity =
                effectiveAvailableQuantity <=
                        0
                    ? 0
                    : _quantity >
                            effectiveAvailableQuantity
                        ? effectiveAvailableQuantity
                        : _quantity;

            // --------------------------------------------------------
            // VARIANT
            // --------------------------------------------------------

            final hasVariant =
                variants.isNotEmpty;

            final variantSelected =
                selectedVariant != null;

            // --------------------------------------------------------
            // CART
            // --------------------------------------------------------

            final canAddToCart =
                effectiveAvailableQuantity >
                        0 &&
                    hasVariant &&
                    variantSelected &&
                    !_addingToCart;

            return RefreshIndicator(
              color:
                  primaryBlue,
              backgroundColor:
                  Colors.white,
              onRefresh:
                  _refresh,
              child:
                  CustomScrollView(
                physics:
                    const AlwaysScrollableScrollPhysics(
                  parent:
                      BouncingScrollPhysics(),
                ),
                slivers: [
                  // ==================================================
                  // HEADER
                  // ==================================================

                  SliverToBoxAdapter(
                    child:
                        Padding(
                      padding:
                          const EdgeInsets
                              .fromLTRB(
                        12,
                        10,
                        18,
                        0,
                      ),
                      child:
                          Row(
                        children: [
                          IconButton(
                            tooltip:
                                'Back',
                            onPressed: () {
                              if (context
                                  .canPop()) {
                                context.pop();
                              } else {
                                context.go(
                                  '/products',
                                );
                              }
                            },
                            icon:
                                const Icon(
                              Icons
                                  .arrow_back_rounded,
                              color:
                                  darkBlue,
                            ),
                          ),

                          const Expanded(
                            child:
                                Text(
                              'Product Details',
                              style:
                                  TextStyle(
                                fontSize:
                                    22,
                                fontWeight:
                                    FontWeight
                                        .w900,
                                color:
                                    darkBlue,
                              ),
                            ),
                          ),

                          // ------------------------------------------------
                          // WISHLIST BUTTON
                          // ------------------------------------------------

                          AnimatedSwitcher(
                            duration:
                                const Duration(
                              milliseconds:
                                  180,
                            ),
                            child:
                                _wishlistUpdating
                                    ? const SizedBox(
                                        key:
                                            ValueKey(
                                          'loading',
                                        ),
                                        width:
                                            48,
                                        height:
                                            48,
                                        child:
                                            Center(
                                          child:
                                              SizedBox(
                                            width:
                                                21,
                                            height:
                                                21,
                                            child:
                                                CircularProgressIndicator(
                                              strokeWidth:
                                                  2.2,
                                              color:
                                                  primaryBlue,
                                            ),
                                          ),
                                        ),
                                      )
                                    : IconButton(
                                        key:
                                            ValueKey(
                                          isInWishlist,
                                        ),
                                        tooltip:
                                            isInWishlist
                                                ? 'Remove from wishlist'
                                                : 'Add to wishlist',
                                        onPressed:
                                            () {
                                          _toggleFavorite(
                                            product.uuid,
                                          );
                                        },
                                        icon:
                                            Icon(
                                          isInWishlist
                                              ? Icons
                                                  .favorite_rounded
                                              : Icons
                                                  .favorite_border_rounded,
                                          color:
                                              isInWishlist
                                                  ? Colors.red
                                                  : darkBlue,
                                        ),
                                      ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ==================================================
                  // IMAGE
                  // ==================================================

                  SliverToBoxAdapter(
                    child:
                        Padding(
                      padding:
                          const EdgeInsets
                              .fromLTRB(
                        20,
                        8,
                        20,
                        0,
                      ),
                      child:
                          _ProductImageGallery(
                        images:
                            images,
                        selectedIndex:
                            safeSelectedImage,
                        onChanged:
                            (index) {
                          setState(() {
                            _selectedImage =
                                index;
                          });
                        },
                      ),
                    ),
                  ),

                  // ==================================================
                  // PRODUCT DETAILS
                  // ==================================================

                  SliverToBoxAdapter(
                    child:
                        Padding(
                      padding:
                          const EdgeInsets
                              .fromLTRB(
                        24,
                        22,
                        24,
                        0,
                      ),
                      child:
                          Column(
                        crossAxisAlignment:
                            CrossAxisAlignment
                                .start,
                        children: [
                          Row(
                            children: [
                              _StatusBadge(
                                label:
                                    product.status
                                        .toUpperCase(),
                                color:
                                    primaryBlue,
                                background:
                                    lightBlue,
                              ),
                              if (product
                                  .isFeatured)
                                const Padding(
                                  padding:
                                      EdgeInsets
                                          .only(
                                    left:
                                        8,
                                  ),
                                  child:
                                      _StatusBadge(
                                    label:
                                        'FEATURED',
                                    color:
                                        Color(
                                      0xFFB36B00,
                                    ),
                                    background:
                                        Color(
                                      0xFFFFF7E6,
                                    ),
                                  ),
                                ),
                            ],
                          ),

                          const SizedBox(
                            height:
                                12,
                          ),

                          Text(
                            product.name,
                            style:
                                const TextStyle(
                              fontSize:
                                  24,
                              height:
                                  1.15,
                              fontWeight:
                                  FontWeight
                                      .w900,
                              color:
                                  darkBlue,
                            ),
                          ),

                          const SizedBox(
                            height:
                                12,
                          ),

                          Row(
                            crossAxisAlignment:
                                CrossAxisAlignment
                                    .center,
                            children: [
                              Text(
                                _money(
                                  selectedVariant
                                          ?.price ??
                                      product
                                          .sellingPrice,
                                ),
                                style:
                                    const TextStyle(
                                  fontSize:
                                      23,
                                  fontWeight:
                                      FontWeight
                                          .w900,
                                  color:
                                      primaryBlue,
                                ),
                              ),

                              if (product
                                  .hasDiscount)
                                Padding(
                                  padding:
                                      const EdgeInsets
                                          .only(
                                    left:
                                        10,
                                  ),
                                  child:
                                      Text(
                                    _money(
                                      product.price,
                                    ),
                                    style:
                                        TextStyle(
                                      fontSize:
                                          14,
                                      color:
                                          Colors
                                              .grey
                                              .shade500,
                                      decoration:
                                          TextDecoration
                                              .lineThrough,
                                    ),
                                  ),
                                ),
                            ],
                          ),

                          const SizedBox(
                            height:
                                20,
                          ),

                          const Text(
                            'Description',
                            style:
                                TextStyle(
                              fontSize:
                                  17,
                              fontWeight:
                                  FontWeight
                                      .w800,
                              color:
                                  darkBlue,
                            ),
                          ),

                          const SizedBox(
                            height:
                                8,
                          ),

                          Text(
                            product.description,
                            style:
                                TextStyle(
                              fontSize:
                                  14,
                              height:
                                  1.55,
                              color:
                                  Colors
                                      .grey
                                      .shade700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ==================================================
                  // PRODUCT INFORMATION
                  // ==================================================

                  SliverToBoxAdapter(
                    child:
                        Padding(
                      padding:
                          const EdgeInsets
                              .fromLTRB(
                        24,
                        24,
                        24,
                        0,
                      ),
                      child:
                          _ProductInformation(
                        brand:
                            product.brand,
                        origin:
                            product.origin,
                        sku:
                            product.sku,
                        unit:
                            product.unit,
                      ),
                    ),
                  ),

                  // ==================================================
                  // VARIANTS
                  // ==================================================

                  if (variants.isNotEmpty)
                    SliverToBoxAdapter(
                      child:
                          Padding(
                        padding:
                            const EdgeInsets
                                .fromLTRB(
                          24,
                          24,
                          24,
                          0,
                        ),
                        child:
                            _VariantSection(
                          variants:
                              variants,
                          selected:
                              _selectedVariant,
                          onSelected:
                              (variant) {
                            if (variant
                                    .quantity <=
                                0) {
                              return;
                            }

                            setState(() {
                              _selectedVariant =
                                  variant.uuid;
                              _quantity =
                                  1;
                            });
                          },
                        ),
                      ),
                    ),

                  // ==================================================
                  // NO VARIANT
                  // ==================================================

                  if (variants.isEmpty)
                    const SliverToBoxAdapter(
                      child:
                          Padding(
                        padding:
                            EdgeInsets
                                .fromLTRB(
                          24,
                          24,
                          24,
                          0,
                        ),
                        child:
                            _NoVariantInformation(),
                      ),
                    ),

                  // ==================================================
                  // STOCK
                  // ==================================================

                  SliverToBoxAdapter(
                    child:
                        Padding(
                      padding:
                          const EdgeInsets
                              .fromLTRB(
                        24,
                        24,
                        24,
                        0,
                      ),
                      child:
                          _StockInformation(
                        quantity:
                            effectiveAvailableQuantity,
                        unit:
                            product.unit,
                      ),
                    ),
                  ),

                  // ==================================================
                  // QUANTITY
                  // ==================================================

                  SliverToBoxAdapter(
                    child:
                        Padding(
                      padding:
                          const EdgeInsets
                              .fromLTRB(
                        24,
                        20,
                        24,
                        0,
                      ),
                      child:
                          _QuantitySection(
                        quantity:
                            effectiveQuantity,
                        available:
                            effectiveAvailableQuantity,
                        onMinus:
                            _decreaseQuantity,
                        onPlus:
                            () {
                          _increaseQuantity(
                            effectiveAvailableQuantity,
                          );
                        },
                      ),
                    ),
                  ),

                  // ==================================================
                  // ADD TO CART
                  // ==================================================

                  SliverToBoxAdapter(
                    child:
                        Padding(
                      padding:
                          const EdgeInsets
                              .fromLTRB(
                        24,
                        26,
                        24,
                        35,
                      ),
                      child:
                          SizedBox(
                        width:
                            double.infinity,
                        height:
                            54,
                        child:
                            ElevatedButton(
                          onPressed:
                              canAddToCart
                                  ? () {
                                      _addToCart(
                                        variantUuid:
                                            selectedVariant
                                                ?.uuid,
                                        availableQuantity:
                                            effectiveAvailableQuantity,
                                      );
                                    }
                                  : null,
                          style:
                              ElevatedButton
                                  .styleFrom(
                            backgroundColor:
                                primaryBlue,
                            disabledBackgroundColor:
                                Colors
                                    .grey
                                    .shade300,
                            elevation:
                                0,
                            shape:
                                RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius
                                      .circular(
                                15,
                              ),
                            ),
                          ),
                          child:
                              _addingToCart
                                  ? const SizedBox(
                                      width:
                                          22,
                                      height:
                                          22,
                                      child:
                                          CircularProgressIndicator(
                                        strokeWidth:
                                            2.5,
                                        color:
                                            Colors.white,
                                      ),
                                    )
                                  : Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment
                                              .center,
                                      children: [
                                        Icon(
                                          canAddToCart
                                              ? Icons
                                                  .shopping_bag_outlined
                                              : Icons
                                                  .remove_shopping_cart_outlined,
                                          size:
                                              20,
                                          color:
                                              Colors.white,
                                        ),
                                        const SizedBox(
                                          width:
                                              9,
                                        ),
                                        Text(
                                          _buttonText(
                                            hasVariant:
                                                hasVariant,
                                            variantSelected:
                                                variantSelected,
                                            stock:
                                                effectiveAvailableQuantity,
                                          ),
                                          style:
                                              const TextStyle(
                                            color:
                                                Colors.white,
                                            fontSize:
                                                15,
                                            fontWeight:
                                                FontWeight
                                                    .w800,
                                          ),
                                        ),
                                      ],
                                    ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ================================================================
  // BUTTON TEXT
  // ================================================================

  String _buttonText({
    required bool hasVariant,
    required bool variantSelected,
    required int stock,
  }) {
    if (_addingToCart) {
      return 'Adding to Cart...';
    }

    if (stock <= 0) {
      return 'Out of Stock';
    }

    if (!hasVariant) {
      return 'Variant Unavailable';
    }

    if (!variantSelected) {
      return 'Select Variant';
    }

    return 'Add to Cart';
  }

  // ================================================================
  // MONEY
  // ================================================================

  String _money(
    double value,
  ) {
    return '₦${value.toStringAsFixed(2)}';
  }
}

// ====================================================================
// STATUS BADGE
// ====================================================================

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({
    required this.label,
    required this.color,
    required this.background,
  });

  final String label;
  final Color color;
  final Color background;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      decoration:
          BoxDecoration(
        color:
            background,
        borderRadius:
            BorderRadius.circular(
          20,
        ),
      ),
      child:
          Text(
        label,
        style:
            TextStyle(
          fontSize: 10,
          fontWeight:
              FontWeight.w800,
          color:
              color,
        ),
      ),
    );
  }
}

// ====================================================================
// IMAGE GALLERY
// ====================================================================

class _ProductImageGallery
    extends StatelessWidget {
  const _ProductImageGallery({
    required this.images,
    required this.selectedIndex,
    required this.onChanged,
  });

  final List<ProductImageModel> images;
  final int selectedIndex;
  final ValueChanged<int> onChanged;

  @override
  Widget build(
    BuildContext context,
  ) {
    final hasImages =
        images.isNotEmpty;

    final safeIndex =
        hasImages
            ? selectedIndex.clamp(
                0,
                images.length - 1,
              )
            : 0;

    return Column(
      children: [
        Container(
          width:
              double.infinity,
          height:
              340,
          decoration:
              BoxDecoration(
            color:
                const Color(
              0xFFF5F8FC,
            ),
            borderRadius:
                BorderRadius.circular(
              22,
            ),
            border:
                Border.all(
              color:
                  const Color(
                0xFFE7EDF5,
              ),
            ),
          ),
          child:
              ClipRRect(
            borderRadius:
                BorderRadius.circular(
              22,
            ),
            child:
                hasImages
                    ? _ImageWidget(
                        path:
                            images[
                                safeIndex]
                                .image,
                      )
                    : const _EmptyProductImage(),
          ),
        ),

        if (images.length > 1)
          Padding(
            padding:
                const EdgeInsets.only(
              top: 12,
            ),
            child:
                SizedBox(
              height:
                  70,
              child:
                  ListView.separated(
                scrollDirection:
                    Axis.horizontal,
                itemCount:
                    images.length,
                separatorBuilder:
                    (_, __) =>
                        const SizedBox(
                  width:
                      10,
                ),
                itemBuilder:
                    (
                  context,
                  index,
                ) {
                  final selected =
                      index ==
                          safeIndex;

                  return GestureDetector(
                    onTap:
                        () {
                      onChanged(
                        index,
                      );
                    },
                    child:
                        AnimatedContainer(
                      duration:
                          const Duration(
                        milliseconds:
                            180,
                      ),
                      width:
                          70,
                      height:
                          70,
                      padding:
                          const EdgeInsets
                              .all(
                        2,
                      ),
                      decoration:
                          BoxDecoration(
                        color:
                            Colors.white,
                        borderRadius:
                            BorderRadius
                                .circular(
                          12,
                        ),
                        border:
                            Border.all(
                          color:
                              selected
                                  ? primaryBlue
                                  : borderColor,
                          width:
                              selected
                                  ? 2
                                  : 1,
                        ),
                      ),
                      child:
                          ClipRRect(
                        borderRadius:
                            BorderRadius
                                .circular(
                          10,
                        ),
                        child:
                            _ImageWidget(
                          path:
                              images[
                                  index]
                                  .image,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
      ],
    );
  }
}

// ====================================================================
// EMPTY PRODUCT IMAGE
// ====================================================================

class _EmptyProductImage
    extends StatelessWidget {
  const _EmptyProductImage();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      color:
          const Color(
        0xFFF4F8FF,
      ),
      child:
          const Center(
        child:
            Icon(
          Icons.image_outlined,
          size:
              75,
          color:
              primaryBlue,
        ),
      ),
    );
  }
}

// ====================================================================
// IMAGE
// ====================================================================

class _ImageWidget
    extends StatelessWidget {
  const _ImageWidget({
    required this.path,
  });

  final String path;

  @override
  Widget build(
    BuildContext context,
  ) {
    final imageUrl =
        _buildImageUrl(
      path,
    );

    if (imageUrl.isEmpty) {
      return const _ImageFallback();
    }

    return Image.network(
      imageUrl,
      width:
          double.infinity,
      height:
          double.infinity,
      fit:
          BoxFit.cover,
      filterQuality:
          FilterQuality.high,
      loadingBuilder:
          (
        context,
        child,
        loadingProgress,
      ) {
        if (loadingProgress ==
            null) {
          return child;
        }

        return const _ImageLoading();
      },
      errorBuilder:
          (
        context,
        error,
        stackTrace,
      ) {
        debugPrint(
          'KwariHub product image failed: $imageUrl',
        );

        return const _ImageFallback();
      },
    );
  }

  String _buildImageUrl(
    String path,
  ) {
    var cleanPath =
        path.trim();

    if (cleanPath.isEmpty) {
      return '';
    }

    // Backend may already return a complete URL.
    if (cleanPath.startsWith(
          'http://',
        ) ||
        cleanPath.startsWith(
          'https://',
        )) {
      return cleanPath;
    }

    // Remove leading slashes.
    while (
        cleanPath.startsWith('/')) {
      cleanPath =
          cleanPath.substring(
        1,
      );
    }

    // Backend returns values such as:
    // storage/products/file.png
    //
    // Therefore we append directly to the
    // Railway backend root.

    return '${AppConfig.storageBaseUrl}/$cleanPath';
  }
}

// ====================================================================
// IMAGE LOADING
// ====================================================================

class _ImageLoading
    extends StatelessWidget {
  const _ImageLoading();

  @override
  Widget build(
    BuildContext context,
  ) {
    return const Center(
      child:
          CircularProgressIndicator(
        strokeWidth:
            2.5,
        color:
            primaryBlue,
      ),
    );
  }
}

// ====================================================================
// IMAGE FALLBACK
// ====================================================================

class _ImageFallback
    extends StatelessWidget {
  const _ImageFallback();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      color:
          const Color(
        0xFFF4F8FF,
      ),
      child:
          const Center(
        child:
            Icon(
          Icons.image_outlined,
          size:
              70,
          color:
              primaryBlue,
        ),
      ),
    );
  }
}

// ====================================================================
// PRODUCT INFORMATION
// ====================================================================

class _ProductInformation
    extends StatelessWidget {
  const _ProductInformation({
    required this.brand,
    required this.origin,
    required this.sku,
    required this.unit,
  });

  final String? brand;
  final String? origin;
  final String sku;
  final String unit;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.all(
        16,
      ),
      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFFAFCFF,
        ),
        borderRadius:
            BorderRadius.circular(
          17,
        ),
        border:
            Border.all(
          color:
              borderColor,
        ),
      ),
      child:
          Column(
        children: [
          _InfoRow(
            label:
                'Brand',
            value:
                _display(
              brand,
            ),
          ),
          _InfoRow(
            label:
                'Origin',
            value:
                _display(
              origin,
            ),
          ),
          _InfoRow(
            label:
                'SKU',
            value:
                _display(
              sku,
            ),
          ),
          _InfoRow(
            label:
                'Unit',
            value:
                _display(
              unit,
            ),
            last:
                true,
          ),
        ],
      ),
    );
  }

  String _display(
    String? value,
  ) {
    if (value == null ||
        value.trim().isEmpty) {
      return 'Not specified';
    }

    return value;
  }
}

// ====================================================================
// INFO ROW
// ====================================================================

class _InfoRow
    extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
    this.last = false,
  });

  final String label;
  final String value;
  final bool last;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        vertical: 10,
      ),
      decoration:
          last
              ? null
              : const BoxDecoration(
                  border:
                      Border(
                    bottom:
                        BorderSide(
                      color:
                          Color(
                        0xFFE8EEF5,
                      ),
                    ),
                  ),
                ),
      child:
          Row(
        children: [
          Expanded(
            child:
                Text(
              label,
              style:
                  TextStyle(
                fontSize:
                    13,
                color:
                    Colors
                        .grey
                        .shade600,
              ),
            ),
          ),
          const SizedBox(
            width:
                16,
          ),
          Flexible(
            child:
                Text(
              value,
              textAlign:
                  TextAlign.right,
              maxLines:
                  2,
              overflow:
                  TextOverflow
                      .ellipsis,
              style:
                  const TextStyle(
                fontSize:
                    13,
                fontWeight:
                    FontWeight
                        .w700,
                color:
                    darkBlue,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ====================================================================
// STOCK
// ====================================================================

class _StockInformation
    extends StatelessWidget {
  const _StockInformation({
    required this.quantity,
    required this.unit,
  });

  final int quantity;
  final String unit;

  @override
  Widget build(
    BuildContext context,
  ) {
    final inStock =
        quantity > 0;

    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal:
            15,
        vertical:
            13,
      ),
      decoration:
          BoxDecoration(
        color:
            inStock
                ? const Color(
                    0xFFF3FBF6,
                  )
                : const Color(
                    0xFFFFF4F4,
                  ),
        borderRadius:
            BorderRadius.circular(
          13,
        ),
        border:
            Border.all(
          color:
              inStock
                  ? const Color(
                      0xFFD7EEDF,
                    )
                  : const Color(
                      0xFFF0D5D5,
                    ),
        ),
      ),
      child:
          Row(
        children: [
          Icon(
            inStock
                ? Icons
                    .check_circle_outline_rounded
                : Icons
                    .remove_circle_outline_rounded,
            size:
                20,
            color:
                inStock
                    ? Colors
                        .green
                        .shade700
                    : Colors
                        .red
                        .shade700,
          ),
          const SizedBox(
            width:
                9,
          ),
          Expanded(
            child:
                Text(
              inStock
                  ? '$quantity $unit available'
                  : 'Currently out of stock',
              style:
                  TextStyle(
                fontSize:
                    13,
                fontWeight:
                    FontWeight
                        .w700,
                color:
                    inStock
                        ? Colors
                            .green
                            .shade700
                        : Colors
                            .red
                            .shade700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ====================================================================
// NO VARIANT
// ====================================================================

class _NoVariantInformation
    extends StatelessWidget {
  const _NoVariantInformation();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.all(
        14,
      ),
      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFFFF8EC,
        ),
        borderRadius:
            BorderRadius.circular(
          13,
        ),
        border:
            Border.all(
          color:
              const Color(
            0xFFF2DFC0,
          ),
        ),
      ),
      child:
          Row(
        children: [
          const Icon(
            Icons
                .info_outline_rounded,
            size:
                20,
            color:
                Color(
              0xFFB36B00,
            ),
          ),
          const SizedBox(
            width:
                9,
          ),
          Expanded(
            child:
                Text(
              'This product currently has no purchasable variant.',
              style:
                  TextStyle(
                fontSize:
                    12,
                fontWeight:
                    FontWeight
                        .w600,
                color:
                    Colors
                        .brown
                        .shade700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ====================================================================
// VARIANTS
// ====================================================================

class _VariantSection
    extends StatelessWidget {
  const _VariantSection({
    required this.variants,
    required this.selected,
    required this.onSelected,
  });

  final List<ProductVariantModel>
      variants;

  final String? selected;

  final ValueChanged<ProductVariantModel>
      onSelected;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        const Text(
          'Available Variants',
          style:
              TextStyle(
            fontSize:
                17,
            fontWeight:
                FontWeight
                    .w800,
            color:
                darkBlue,
          ),
        ),
        const SizedBox(
          height:
              12,
        ),
        Wrap(
          spacing:
              10,
          runSpacing:
              10,
          children:
              variants.map(
            (
              variant,
            ) {
              final isSelected =
                  selected ==
                      variant.uuid;

              final available =
                  variant.quantity >
                      0;

              return GestureDetector(
                onTap:
                    available
                        ? () {
                            onSelected(
                              variant,
                            );
                          }
                        : null,
                child:
                    AnimatedContainer(
                  duration:
                      const Duration(
                    milliseconds:
                        180,
                  ),
                  padding:
                      const EdgeInsets
                          .symmetric(
                    horizontal:
                        13,
                    vertical:
                        10,
                  ),
                  decoration:
                      BoxDecoration(
                    color:
                        !available
                            ? Colors
                                .grey
                                .shade100
                            : isSelected
                                ? lightBlue
                                : Colors
                                    .white,
                    borderRadius:
                        BorderRadius
                            .circular(
                      12,
                    ),
                    border:
                        Border.all(
                      color:
                          isSelected
                              ? primaryBlue
                              : borderColor,
                      width:
                          isSelected
                              ? 1.5
                              : 1,
                    ),
                  ),
                  child:
                      Column(
                    crossAxisAlignment:
                        CrossAxisAlignment
                            .start,
                    children: [
                      Row(
                        mainAxisSize:
                            MainAxisSize
                                .min,
                        children: [
                          Text(
                            variant
                                .color,
                            style:
                                TextStyle(
                              fontSize:
                                  12,
                              fontWeight:
                                  FontWeight
                                      .w800,
                              color:
                                  available
                                      ? darkBlue
                                      : Colors
                                          .grey
                                          .shade500,
                            ),
                          ),
                          if (isSelected)
                            const Padding(
                              padding:
                                  EdgeInsets
                                      .only(
                                left:
                                    5,
                              ),
                              child:
                                  Icon(
                                Icons
                                    .check_circle_rounded,
                                size:
                                    14,
                                color:
                                    primaryBlue,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(
                        height:
                            3,
                      ),
                      Text(
                        '${variant.size} • ${variant.material}',
                        style:
                            TextStyle(
                          fontSize:
                              10,
                          color:
                              Colors
                                  .grey
                                  .shade600,
                        ),
                      ),
                      const SizedBox(
                        height:
                            4,
                      ),
                      Text(
                        available
                            ? '${variant.quantity} available'
                            : 'Out of stock',
                        style:
                            TextStyle(
                          fontSize:
                              9,
                          fontWeight:
                              FontWeight
                                  .w600,
                          color:
                              available
                                  ? Colors
                                      .green
                                      .shade700
                                  : Colors
                                      .red
                                      .shade600,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ).toList(),
        ),
      ],
    );
  }
}

// ====================================================================
// QUANTITY
// ====================================================================

class _QuantitySection
    extends StatelessWidget {
  const _QuantitySection({
    required this.quantity,
    required this.available,
    required this.onMinus,
    required this.onPlus,
  });

  final int quantity;
  final int available;

  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(
    BuildContext context,
  ) {
    final canDecrease =
        quantity > 1;

    final canIncrease =
        quantity < available;

    return Row(
      children: [
        const Expanded(
          child:
              Column(
            crossAxisAlignment:
                CrossAxisAlignment
                    .start,
            children: [
              Text(
                'Quantity',
                style:
                    TextStyle(
                  fontSize:
                      17,
                  fontWeight:
                      FontWeight
                          .w800,
                  color:
                      darkBlue,
                ),
              ),
              SizedBox(
                height:
                    3,
              ),
              Text(
                'Select quantity',
                style:
                    TextStyle(
                  fontSize:
                      11,
                  color:
                      Colors.grey,
                ),
              ),
            ],
          ),
        ),
        Container(
          height:
              46,
          decoration:
              BoxDecoration(
            color:
                const Color(
              0xFFFAFCFF,
            ),
            borderRadius:
                BorderRadius.circular(
              13,
            ),
            border:
                Border.all(
              color:
                  borderColor,
            ),
          ),
          child:
              Row(
            mainAxisSize:
                MainAxisSize
                    .min,
            children: [
              IconButton(
                onPressed:
                    canDecrease
                        ? onMinus
                        : null,
                splashRadius:
                    20,
                icon:
                    const Icon(
                  Icons
                      .remove_rounded,
                  size:
                      19,
                ),
              ),
              SizedBox(
                width:
                    25,
                child:
                    Text(
                  '$quantity',
                  textAlign:
                      TextAlign
                          .center,
                  style:
                      const TextStyle(
                    fontSize:
                        15,
                    fontWeight:
                        FontWeight
                            .w800,
                    color:
                        darkBlue,
                  ),
                ),
              ),
              IconButton(
                onPressed:
                    canIncrease
                        ? onPlus
                        : null,
                splashRadius:
                    20,
                icon:
                    const Icon(
                  Icons
                      .add_rounded,
                  size:
                      19,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ====================================================================
// LOADING
// ====================================================================

class _ProductLoading
    extends StatelessWidget {
  const _ProductLoading();

  @override
  Widget build(
    BuildContext context,
  ) {
    return const Center(
      child:
          CircularProgressIndicator(
        color:
            primaryBlue,
      ),
    );
  }
}

// ====================================================================
// ERROR
// ====================================================================

class _ProductError
    extends StatelessWidget {
  const _ProductError({
    required this.message,
    required this.onRetry,
  });

  final String message;

  final Future<void> Function()
      onRetry;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Center(
      child:
          Padding(
        padding:
            const EdgeInsets.all(
          24,
        ),
        child:
            Column(
          mainAxisAlignment:
              MainAxisAlignment
                  .center,
          children: [
            Container(
              width:
                  72,
              height:
                  72,
              decoration:
                  BoxDecoration(
                color:
                    lightBlue,
                borderRadius:
                    BorderRadius
                        .circular(
                  20,
                ),
              ),
              child:
                  const Icon(
                Icons
                    .cloud_off_rounded,
                size:
                    34,
                color:
                    primaryBlue,
              ),
            ),
            const SizedBox(
              height:
                  18,
            ),
            const Text(
              'Unable to load product',
              textAlign:
                  TextAlign.center,
              style:
                  TextStyle(
                fontSize:
                    19,
                fontWeight:
                    FontWeight
                        .w800,
                color:
                    darkBlue,
              ),
            ),
            const SizedBox(
              height:
                  8,
            ),
            Text(
              message,
              textAlign:
                  TextAlign.center,
              maxLines:
                  4,
              overflow:
                  TextOverflow
                      .ellipsis,
              style:
                  TextStyle(
                fontSize:
                    13,
                color:
                    Colors
                        .grey
                        .shade600,
              ),
            ),
            const SizedBox(
              height:
                  20,
            ),
            SizedBox(
              height:
                  48,
              child:
                  ElevatedButton(
                onPressed:
                    onRetry,
                style:
                    ElevatedButton
                        .styleFrom(
                  backgroundColor:
                      primaryBlue,
                  elevation:
                      0,
                  shape:
                      RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius
                            .circular(
                      13,
                    ),
                  ),
                ),
                child:
                    const Text(
                  'Try Again',
                  style:
                      TextStyle(
                    color:
                        Colors.white,
                    fontWeight:
                        FontWeight
                            .w800,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}