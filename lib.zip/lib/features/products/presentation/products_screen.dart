import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:kwarihub/features/auth/presentation/login_screen.dart';

import '../models/product_model.dart';
import '../providers/products_provider.dart';

class ProductsScreen extends ConsumerStatefulWidget {
  const ProductsScreen({
    super.key,
    this.categoryId,
  });

  final String? categoryId;

  @override
  ConsumerState<ProductsScreen> createState() =>
      _ProductsScreenState();
}

class _ProductsScreenState
    extends ConsumerState<ProductsScreen> {
  static const Color primaryBlue =
      Color(0xFF0D5CC7);

  static const Color darkBlue =
      Color(0xFF102F4F);

  static const Color lightBlue =
      Color(0xFFF4F8FF);

  static const Color borderColor =
      Color(0xFFDDE6F0);

  final TextEditingController
      _searchController =
      TextEditingController();

  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    ref.invalidate(productsProvider);

    await ref.read(
      productsProvider.future,
    );
  }

  List<ProductModel> _filterProducts(
    List<ProductModel> products,
  ) {
    var result = products;

    // ==========================================================
    // CATEGORY FILTER
    // ==========================================================

    if (widget.categoryId != null) {
      final categoryId =
          int.tryParse(widget.categoryId!);

      if (categoryId != null) {
        result = result
            .where(
              (product) =>
                  product.categoryId ==
                  categoryId,
            )
            .toList();
      }
    }

    // ==========================================================
    // SEARCH FILTER
    // ==========================================================

    final query = _searchQuery
        .trim()
        .toLowerCase();

    if (query.isEmpty) {
      return result;
    }

    return result
        .where(
          (product) {
            return product.name
                    .toLowerCase()
                    .contains(query) ||
                product.slug
                    .toLowerCase()
                    .contains(query) ||
                product.sku
                    .toLowerCase()
                    .contains(query) ||
                (product.brand
                        ?.toLowerCase()
                        .contains(query) ??
                    false);
          },
        )
        .toList();
  }

  void _openProduct(
    ProductModel product,
  ) {
    context.push(
      '/products/${product.uuid}',
    );
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    final productsAsync =
        ref.watch(productsProvider);

    return Scaffold(
      backgroundColor: Colors.white,

      body: SafeArea(
        child: productsAsync.when(
          loading: () {
            return const _ProductsLoading();
          },

          error: (
            error,
            stackTrace,
          ) {
            return _ProductsError(
              message: error
                  .toString()
                  .replaceFirst(
                    'Exception: ',
                    '',
                  ),
              onRetry: () {
                ref.invalidate(
                  productsProvider,
                );
              },
            );
          },

          data: (
            products,
          ) {
            final filtered =
                _filterProducts(
              products,
            );

            return RefreshIndicator(
              color: primaryBlue,
              onRefresh: _refresh,

              child: CustomScrollView(
                physics:
                    const AlwaysScrollableScrollPhysics(
                  parent:
                      BouncingScrollPhysics(),
                ),

                slivers: [
                  // ==================================================
                  // HEADER
                  // ==================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        18,
                        24,
                        0,
                      ),

                      child: Row(
                        children: [
                          IconButton(
                            onPressed: () {
                              context.pop();
                            },

                            icon:
                                const Icon(
                              Icons
                                  .arrow_back_rounded,
                              color:
                                  darkBlue,
                            ),
                          ),

                          const SizedBox(
                            width: 4,
                          ),

                          const Expanded(
                            child: Text(
                              'Products',
                              style:
                                  TextStyle(
                                fontSize: 24,
                                fontWeight:
                                    FontWeight.w900,
                                color:
                                    darkBlue,
                              ),
                            ),
                          ),

                          Image.asset(
                            'assets/images/kwarihub_logo.png',
                            width: 92,
                            height: 36,
                            fit:
                                BoxFit.contain,
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ==================================================
                  // SEARCH
                  // ==================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        18,
                        24,
                        0,
                      ),

                      child:
                          _buildSearchBar(),
                    ),
                  ),

                  // ==================================================
                  // COUNT
                  // ==================================================

                  SliverToBoxAdapter(
                    child: Padding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        22,
                        24,
                        0,
                      ),

                      child: Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Products',
                              style:
                                  TextStyle(
                                fontSize: 20,
                                fontWeight:
                                    FontWeight.w900,
                                color:
                                    darkBlue,
                              ),
                            ),
                          ),

                          Text(
                            '${filtered.length} items',
                            style:
                                TextStyle(
                              fontSize: 12,
                              color: Colors
                                  .grey
                                  .shade600,
                              fontWeight:
                                  FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ==================================================
                  // EMPTY
                  // ==================================================

                  if (filtered.isEmpty)
                    const SliverToBoxAdapter(
                      child:
                          Padding(
                        padding:
                            EdgeInsets.all(
                          24,
                        ),
                        child:
                            _EmptyProducts(),
                      ),
                    ),

                  // ==================================================
                  // GRID
                  // ==================================================

                  if (filtered.isNotEmpty)
                    SliverPadding(
                      padding:
                          const EdgeInsets.fromLTRB(
                        24,
                        16,
                        24,
                        30,
                      ),

                      sliver:
                          SliverGrid(
                        delegate:
                            SliverChildBuilderDelegate(
                          (
                            context,
                            index,
                          ) {
                            final product =
                                filtered[
                                    index];

                            return _ProductCard(
                              product:
                                  product,

                              onTap:
                                  () {
                                _openProduct(
                                  product,
                                );
                              },
                            );
                          },

                          childCount:
                              filtered.length,
                        ),

                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount:
                              2,

                          crossAxisSpacing:
                              14,

                          mainAxisSpacing:
                              18,

                          childAspectRatio:
                              0.67,
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),

      bottomNavigationBar:
          _buildBottomNavigation(),
    );
  }

  // ============================================================
  // SEARCH
  // ============================================================

  Widget _buildSearchBar() {
    return Container(
      height: 52,

      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFFAFCFF,
        ),

        borderRadius:
            BorderRadius.circular(
          15,
        ),

        border:
            Border.all(
          color:
              borderColor,
        ),
      ),

      child: Row(
        children: [
          const SizedBox(
            width: 15,
          ),

          Icon(
            Icons.search_rounded,
            size: 22,
            color:
                Colors.grey.shade500,
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: TextField(
              controller:
                  _searchController,

              onChanged: (
                value,
              ) {
                setState(() {
                  _searchQuery =
                      value;
                });
              },

              textInputAction:
                  TextInputAction.search,

              decoration:
                  const InputDecoration(
                border:
                    InputBorder.none,

                hintText:
                    'Search products...',

                isDense: true,
              ),

              style:
                  const TextStyle(
                fontSize: 14,
                color:
                    darkBlue,
                fontWeight:
                    FontWeight.w500,
              ),
            ),
          ),

          if (_searchQuery
              .isNotEmpty)
            IconButton(
              onPressed: () {
                _searchController
                    .clear();

                setState(() {
                  _searchQuery =
                      '';
                });
              },

              icon:
                  Icon(
                Icons.close_rounded,
                size: 19,
                color:
                    Colors.grey.shade500,
              ),
            ),

          const SizedBox(
            width: 3,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // BOTTOM NAV
  // ============================================================

  Widget _buildBottomNavigation() {
    return Container(
      decoration:
          BoxDecoration(
        color: Colors.white,

        border:
            Border(
          top:
              BorderSide(
            color:
                borderColor
                    .withOpacity(
              0.7,
            ),
          ),
        ),
      ),

      child:
          SafeArea(
        top: false,

        child:
            Padding(
          padding:
              const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 7,
          ),

          child:
              Row(
            mainAxisAlignment:
                MainAxisAlignment
                    .spaceAround,

            children: [
              _BottomNavItem(
                icon:
                    Icons.home_rounded,
                label:
                    'Home',
                selected:
                    false,
                onTap: () {
                  context.go(
                    '/home',
                  );
                },
              ),

              _BottomNavItem(
                icon:
                    Icons.grid_view_rounded,
                label:
                    'Categories',
                selected:
                    true,
                onTap: () {
                  context.go(
                    '/categories',
                  );
                },
              ),

              _BottomNavItem(
                icon:
                    Icons.shopping_bag_outlined,
                label:
                    'Cart',
                selected:
                    false,
                onTap: () {
                  context.go(
                    '/cart',
                  );
                },
              ),

              _BottomNavItem(
                icon:
                    Icons.favorite_border_rounded,
                label:
                    'Wishlist',
                selected:
                    false,
                onTap: () {
                  context.go(
                    '/wishlist',
                  );
                },
              ),

              _BottomNavItem(
                icon:
                    Icons.person_outline_rounded,
                label:
                    'Profile',
                selected:
                    false,
                onTap: () {
                  context.go(
                    '/profile',
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================================================================
// PRODUCT CARD
// ================================================================

class _ProductCard
    extends StatelessWidget {
  const _ProductCard({
    required this.product,
    required this.onTap,
  });

  final ProductModel product;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: onTap,

      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Expanded(
            child: Container(
              width:
                  double.infinity,

              decoration:
                  BoxDecoration(
                color:
                    lightBlue,

                borderRadius:
                    BorderRadius.circular(
                  17,
                ),

                border:
                    Border.all(
                  color:
                      borderColor,
                ),
              ),

              child:
                  Stack(
                children: [
                  const Center(
                    child: Icon(
                      Icons
                          .checkroom_outlined,
                      size: 48,
                      color:
                          primaryBlue,
                    ),
                  ),

                  if (product
                      .hasDiscount)
                    Positioned(
                      top: 9,
                      left: 9,

                      child:
                          Container(
                        padding:
                            const EdgeInsets
                                .symmetric(
                          horizontal:
                              8,
                          vertical:
                              5,
                        ),

                        decoration:
                            BoxDecoration(
                          color:
                              Colors.red
                                  .shade600,

                          borderRadius:
                              BorderRadius
                                  .circular(
                            8,
                          ),
                        ),

                        child:
                            const Text(
                          'SALE',
                          style:
                              TextStyle(
                            color:
                                Colors.white,
                            fontSize:
                                9,
                            fontWeight:
                                FontWeight
                                    .w800,
                          ),
                        ),
                      ),
                    ),

                  Positioned(
                    top: 8,
                    right: 8,

                    child:
                        Container(
                      padding:
                          const EdgeInsets
                              .all(
                        7,
                      ),

                      decoration:
                          const BoxDecoration(
                        color:
                            Colors.white,
                        shape:
                            BoxShape
                                .circle,
                      ),

                      child:
                          const Icon(
                        Icons
                            .favorite_border_rounded,
                        size: 18,
                        color:
                            darkBlue,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(
            height: 9,
          ),

          Text(
            product.name,

            maxLines: 1,

            overflow:
                TextOverflow.ellipsis,

            style:
                const TextStyle(
              fontSize: 13,
              fontWeight:
                  FontWeight.w800,
              color:
                  darkBlue,
            ),
          ),

          const SizedBox(
            height: 4,
          ),

          Text(
            product.brand ??
                product.unit,

            maxLines: 1,

            overflow:
                TextOverflow.ellipsis,

            style:
                TextStyle(
              fontSize: 11,
              color:
                  Colors.grey.shade500,
            ),
          ),

          const SizedBox(
            height: 5,
          ),

          Row(
            children: [
              Text(
                _formatPrice(
                  product.sellingPrice,
                ),

                style:
                    const TextStyle(
                  fontSize: 14,
                  fontWeight:
                      FontWeight.w900,
                  color:
                      primaryBlue,
                ),
              ),

              if (product
                  .hasDiscount)
                Padding(
                  padding:
                      const EdgeInsets
                          .only(
                    left: 6,
                  ),

                  child: Text(
                    _formatPrice(
                      product.price,
                    ),

                    style:
                        TextStyle(
                      fontSize: 10,
                      color: Colors
                          .grey
                          .shade500,

                      decoration:
                          TextDecoration
                              .lineThrough,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatPrice(
    double value,
  ) {
    return NumberFormat.currency(
      locale: 'en_NG',
      symbol: '₦',
      decimalDigits: 0,
    ).format(value);
  }
}

// ================================================================
// BOTTOM NAV ITEM
// ================================================================

class _BottomNavItem
    extends StatelessWidget {
  const _BottomNavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: onTap,
      behavior:
          HitTestBehavior.opaque,

      child: SizedBox(
        width: 65,

        child: Column(
          mainAxisSize:
              MainAxisSize.min,

          children: [
            Icon(
              icon,
              size: 24,
              color: selected
                  ? primaryBlue
                  : Colors.grey.shade400,
            ),

            const SizedBox(
              height: 4,
            ),

            Text(
              label,
              maxLines: 1,
              overflow:
                  TextOverflow.ellipsis,

              style: TextStyle(
                fontSize: 10,
                fontWeight: selected
                    ? FontWeight.w700
                    : FontWeight.w500,
                color: selected
                    ? primaryBlue
                    : Colors.grey.shade400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// LOADING
// ================================================================

class _ProductsLoading
    extends StatelessWidget {
  const _ProductsLoading();

  @override
  Widget build(
    BuildContext context,
  ) {
    return const Center(
      child:
          CircularProgressIndicator(
        color:
            Color(0xFF0D5CC7),
      ),
    );
  }
}

// ================================================================
// ERROR
// ================================================================

class _ProductsError
    extends StatelessWidget {
  const _ProductsError({
    required this.message,
    required this.onRetry,
  });

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Center(
      child: Padding(
        padding:
            const EdgeInsets.all(24),

        child: Column(
          mainAxisSize:
              MainAxisSize.min,

          children: [
            Container(
              width: 72,
              height: 72,

              decoration:
                  BoxDecoration(
                color:
                    const Color(
                  0xFFF4F8FF,
                ),

                borderRadius:
                    BorderRadius.circular(
                  20,
                ),
              ),

              child:
                  const Icon(
                Icons.cloud_off_rounded,
                color:
                    Color(0xFF0D5CC7),
                size: 34,
              ),
            ),

            const SizedBox(
              height: 18,
            ),

            const Text(
              'Unable to load products',
              textAlign:
                  TextAlign.center,

              style:
                  TextStyle(
                fontSize: 19,
                fontWeight:
                    FontWeight.w800,
                color:
                    Color(0xFF102F4F),
              ),
            ),

            const SizedBox(
              height: 8,
            ),

            Text(
              message,
              textAlign:
                  TextAlign.center,

              style:
                  TextStyle(
                fontSize: 13,
                color:
                    Colors.grey.shade600,
              ),
            ),

            const SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: onRetry,

              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(
                  0xFF0D5CC7,
                ),
                foregroundColor:
                    Colors.white,
                elevation: 0,
              ),

              child:
                  const Text(
                'Try Again',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// EMPTY
// ================================================================

class _EmptyProducts
    extends StatelessWidget {
  const _EmptyProducts();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(28),

      decoration:
          BoxDecoration(
        color:
            const Color(0xFFFAFCFF),

        borderRadius:
            BorderRadius.circular(18),

        border:
            Border.all(
          color:
              const Color(0xFFEAF0F6),
        ),
      ),

      child:
          Column(
        children: [
          const Icon(
            Icons
                .inventory_2_outlined,
            size: 42,
            color:
                Color(0xFF0D5CC7),
          ),

          const SizedBox(
            height: 12,
          ),

          const Text(
            'No products found',
            style:
                TextStyle(
              fontSize: 16,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF102F4F),
            ),
          ),

          const SizedBox(
            height: 5,
          ),

          Text(
            'There are no products available here yet.',
            textAlign:
                TextAlign.center,
            style:
                TextStyle(
              fontSize: 12,
              color:
                  Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }
}