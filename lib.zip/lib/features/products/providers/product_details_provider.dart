import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/product_api.dart';
import '../models/product_image_model.dart';
import '../models/product_model.dart';
import '../models/product_variant_model.dart';

final productApiProvider = Provider<ProductApi>(
  (ref) => ProductApi(),
);

class ProductDetailsData {
  final ProductModel product;
  final List<ProductImageModel> images;
  final List<ProductVariantModel> variants;

  const ProductDetailsData({
    required this.product,
    required this.images,
    required this.variants,
  });
}

final productDetailsProvider = FutureProvider.autoDispose
    .family<ProductDetailsData, String>(
  (ref, productUuid) async {
    final api = ref.read(
      productApiProvider,
    );

    final product = await api.getProduct(
      productUuid,
    );

    final images = await api.getProductImages(
      productUuid,
    );

    final variants = await api.getProductVariants(
      productUuid,
    );

    return ProductDetailsData(
      product: product,
      images: images,
      variants: variants,
    );
  },
);