class DashboardModel {
  final DashboardUser user;
  final DashboardWallet wallet;
  final DashboardStats stats;
  final List<RecentOrder> recentOrders;
  final List<DashboardProduct> featuredProducts;
  final List<DashboardProduct> latestProducts;
  final List<DashboardCategory> featuredCategories;

  const DashboardModel({
    required this.user,
    required this.wallet,
    required this.stats,
    required this.recentOrders,
    required this.featuredProducts,
    required this.latestProducts,
    required this.featuredCategories,
  });

  factory DashboardModel.fromJson(Map<String, dynamic> json) {
    return DashboardModel(
      user: DashboardUser.fromJson(
        json['user'] as Map<String, dynamic>? ?? {},
      ),
      wallet: DashboardWallet.fromJson(
        json['wallet'] as Map<String, dynamic>? ?? {},
      ),
      stats: DashboardStats.fromJson(
        json['stats'] as Map<String, dynamic>? ?? {},
      ),
      recentOrders: (json['recent_orders'] as List? ?? [])
          .map(
            (item) => RecentOrder.fromJson(
              item as Map<String, dynamic>,
            ),
          )
          .toList(),
      featuredProducts: (json['featured_products'] as List? ?? [])
          .map(
            (item) => DashboardProduct.fromJson(
              item as Map<String, dynamic>,
            ),
          )
          .toList(),
      latestProducts: (json['latest_products'] as List? ?? [])
          .map(
            (item) => DashboardProduct.fromJson(
              item as Map<String, dynamic>,
            ),
          )
          .toList(),
      featuredCategories:
          (json['featured_categories'] as List? ?? [])
              .map(
                (item) => DashboardCategory.fromJson(
                  item as Map<String, dynamic>,
                ),
              )
              .toList(),
    );
  }
}

// ============================================================
// USER
// ============================================================

class DashboardUser {
  final int id;
  final String uuid;
  final String firstName;
  final String lastName;
  final String username;
  final String email;
  final String phone;
  final String? avatar;

  const DashboardUser({
    required this.id,
    required this.uuid,
    required this.firstName,
    required this.lastName,
    required this.username,
    required this.email,
    required this.phone,
    this.avatar,
  });

  factory DashboardUser.fromJson(Map<String, dynamic> json) {
    return DashboardUser(
      id: json['id'] as int? ?? 0,
      uuid: json['uuid']?.toString() ?? '',
      firstName: json['first_name']?.toString() ?? '',
      lastName: json['last_name']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      phone: json['phone']?.toString() ?? '',
      avatar: json['avatar']?.toString(),
    );
  }

  String get displayName {
    final name = '$firstName $lastName'.trim();

    if (name.isNotEmpty) {
      return name;
    }

    return username;
  }

  String get firstNameDisplay {
    if (firstName.trim().isNotEmpty) {
      return firstName.trim();
    }

    if (username.trim().isNotEmpty) {
      return username.trim().split(' ').first;
    }

    return 'User';
  }
}

// ============================================================
// WALLET
// ============================================================

class DashboardWallet {
  final dynamic balance;
  final dynamic totalEarned;
  final dynamic totalWithdrawn;

  const DashboardWallet({
    required this.balance,
    required this.totalEarned,
    required this.totalWithdrawn,
  });

  factory DashboardWallet.fromJson(Map<String, dynamic> json) {
    return DashboardWallet(
      balance: json['balance'] ?? 0,
      totalEarned: json['total_earned'] ?? 0,
      totalWithdrawn: json['total_withdrawn'] ?? 0,
    );
  }

  double get balanceValue => _toDouble(balance);

  double get earnedValue => _toDouble(totalEarned);

  double get withdrawnValue => _toDouble(totalWithdrawn);

  static double _toDouble(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value.toString()) ?? 0;
  }
}

// ============================================================
// DASHBOARD STATS
// ============================================================

class DashboardStats {
  final int cartCount;
  final int wishlistCount;
  final int unreadNotifications;
  final int totalOrders;
  final int pendingOrders;
  final int processingOrders;
  final int deliveredOrders;
  final int cancelledOrders;
  final dynamic totalSpent;

  const DashboardStats({
    required this.cartCount,
    required this.wishlistCount,
    required this.unreadNotifications,
    required this.totalOrders,
    required this.pendingOrders,
    required this.processingOrders,
    required this.deliveredOrders,
    required this.cancelledOrders,
    required this.totalSpent,
  });

  factory DashboardStats.fromJson(Map<String, dynamic> json) {
    return DashboardStats(
      cartCount: _toInt(json['cart_count']),
      wishlistCount: _toInt(json['wishlist_count']),
      unreadNotifications:
          _toInt(json['unread_notifications']),
      totalOrders: _toInt(json['total_orders']),
      pendingOrders: _toInt(json['pending_orders']),
      processingOrders: _toInt(json['processing_orders']),
      deliveredOrders: _toInt(json['delivered_orders']),
      cancelledOrders: _toInt(json['cancelled_orders']),
      totalSpent: json['total_spent'] ?? 0,
    );
  }

  double get totalSpentValue => _toDouble(totalSpent);

  static int _toInt(dynamic value) {
    if (value == null) return 0;

    if (value is int) return value;

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value.toString()) ?? 0;
  }

  static double _toDouble(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value.toString()) ?? 0;
  }
}

// ============================================================
// PRODUCT
// ============================================================

class DashboardProduct {
  final String uuid;
  final String name;
  final String slug;
  final dynamic price;
  final dynamic discountPrice;
  final int quantity;
  final String unit;
  final String? brand;
  final bool isFeatured;
  final String? image;

  const DashboardProduct({
    required this.uuid,
    required this.name,
    required this.slug,
    required this.price,
    required this.discountPrice,
    required this.quantity,
    required this.unit,
    required this.brand,
    required this.isFeatured,
    required this.image,
  });

  factory DashboardProduct.fromJson(
    Map<String, dynamic> json,
  ) {
    return DashboardProduct(
      uuid: json['uuid']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      price: json['price'] ?? 0,
      discountPrice: json['discount_price'],
      quantity: _toInt(json['quantity']),
      unit: json['unit']?.toString() ?? '',
      brand: json['brand']?.toString(),
      isFeatured: json['is_featured'] == true,
      image: json['image']?.toString(),
    );
  }

  double get priceValue => _toDouble(price);

  double? get discountPriceValue {
    if (discountPrice == null) {
      return null;
    }

    final value = _toDouble(discountPrice);

    return value > 0 ? value : null;
  }

  bool get hasDiscount {
    final discount = discountPriceValue;

    return discount != null && discount < priceValue;
  }

  static int _toInt(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value.toString()) ?? 0;
  }

  static double _toDouble(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value.toString()) ?? 0;
  }
}

// ============================================================
// CATEGORY
// ============================================================

class DashboardCategory {
  final String uuid;
  final String name;
  final String slug;
  final String? description;
  final String? icon;
  final bool isFeatured;

  const DashboardCategory({
    required this.uuid,
    required this.name,
    required this.slug,
    required this.description,
    required this.icon,
    required this.isFeatured,
  });

  factory DashboardCategory.fromJson(
    Map<String, dynamic> json,
  ) {
    return DashboardCategory(
      uuid: json['uuid']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      description: json['description']?.toString(),
      icon: json['icon']?.toString(),
      isFeatured: json['is_featured'] == true,
    );
  }
}

// ============================================================
// RECENT ORDER
// ============================================================

class RecentOrder {
  final String uuid;
  final String orderNumber;
  final String status;
  final dynamic total;

  const RecentOrder({
    required this.uuid,
    required this.orderNumber,
    required this.status,
    required this.total,
  });

  factory RecentOrder.fromJson(
    Map<String, dynamic> json,
  ) {
    return RecentOrder(
      uuid: json['uuid']?.toString() ?? '',
      orderNumber:
          json['order_number']?.toString() ?? '',
      status: json['status']?.toString() ?? '',
      total: json['total'] ?? 0,
    );
  }

  double get totalValue {
    if (total is num) {
      return (total as num).toDouble();
    }

    return double.tryParse(total.toString()) ?? 0;
  }
}